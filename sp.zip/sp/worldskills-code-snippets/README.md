# WorldSkills Code Snippets

[![VS Code Version](https://img.shields.io/badge/VS%20Code-1.60.0%2B-blue.svg)](https://code.visualstudio.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/Version-1.0.0-orange.svg)](package.json)

A comprehensive VS Code snippets extension designed specifically for **WorldSkills Web Technologies** competition participants and web developers. This extension provides production-ready code templates for PHP, HTML, CSS, JavaScript, Bootstrap 5, PDO, SQL, CRUD operations, Authentication, API development, Security, and Utilities.

## Introduction

WorldSkills Code Snippets is the ultimate productivity tool for web developers participating in WorldSkills competitions or working on professional web projects. With over 100 carefully crafted snippets, this extension accelerates development by providing ready-to-use code templates that follow best practices and industry standards.

### Why Use This Extension?

- **Save Time**: Insert complex code patterns with a few keystrokes
- **Maintain Consistency**: Follow established coding patterns throughout your project
- **Learn Best Practices**: Each snippet demonstrates professional coding standards
- **Reduce Errors**: Pre-validated code with proper error handling and security measures
- **Focus on Logic**: Spend less time on boilerplate and more on solving problems
- **Competition Ready**: Designed specifically for WorldSkills Web Technologies requirements

## Features

### Comprehensive Snippet Collection

- **100+ Production-Ready Snippets** covering all major web development areas
- **Multi-Language Support**: PHP, HTML, CSS, JavaScript, SQL
- **Framework Integration**: Bootstrap 5 components and utilities
- **Database Operations**: PDO queries, prepared statements, CRUD operations
- **Authentication & Security**: Login, logout, role-based access, CSRF protection
- **API Development**: RESTful endpoints, JSON responses, error handling
- **WorldSkills Specific**: Competition-ready patterns and structures

### Snippet Categories

1. **Database & PDO**
   - Database connection for XAMPP
   - Prepared statements (SELECT, INSERT, UPDATE, DELETE)
   - Dynamic WHERE clause builder
   - Soft delete implementation
   - Bulk insert operations

2. **HTML & Bootstrap 5**
   - Semantic HTML5 templates
   - Bootstrap 5 components (navbar, card, modal, toast, alert)
   - Responsive layouts with grid system
   - Forms with validation
   - Accessible components (WCAG compliant)

3. **CSS**
   - CSS reset and normalization
   - Custom properties (variables)
   - Flexbox and grid layouts
   - Responsive containers
   - Animations and transitions

4. **JavaScript**
   - Fetch API wrappers (GET, POST, PUT, DELETE)
   - DOM manipulation utilities
   - Event handling patterns
   - Debounce and throttle functions
   - Dark mode implementation
   - Toast notifications
   - Image preview
   - Drag and drop file upload
   - Clipboard operations

5. **PHP**
   - Session management
   - Password hashing and verification
   - CSRF token generation
   - Error handling
   - Logging functions
   - UUID generation
   - Slug creation
   - Date helpers
   - Email sending

6. **Authentication & Authorization**
   - Login/logout systems
   - Role-based access control
   - Read-only enforcement
   - Session guards
   - IP/VPN restrictions

7. **API Development**
   - JSON response helpers
   - Standardized error handling
   - RESTful endpoint patterns
   - Status code management
   - Request validation

8. **SQL**
   - Database schema creation
   - Table operations
   - Foreign keys and constraints
   - Indexes and optimization
   - Views and triggers
   - Stored procedures

9. **Security**
   - XSS protection
   - SQL injection prevention
   - Rate limiting
   - Session timeout
   - Input validation

10. **Dashboard & UI**
    - Statistics cards
    - Data visualization
    - Responsive layouts
    - User interfaces

11. **WorldSkills Specific**
    - Project structure templates
    - MVC folder organization
    - Competition-ready patterns
    - Installation scripts

## Installation

### From VS Code Marketplace

1. Open VS Code
2. Press `Ctrl + Shift + X` to open Extensions view
3. Search for "WorldSkills Code Snippets"
4. Click **Install**
5. Reload VS Code when prompted

### From VSIX File

1. Download the latest `.vsix` file from the [Releases](https://github.com/worldskills/worldskills-code-snippets/releases) page
2. Open VS Code
3. Press `Ctrl + Shift + P` to open Command Palette
4. Type "Extensions: Install from VSIX"
5. Select the downloaded `.vsix` file
6. Reload VS Code when prompted

### Manual Installation

1. Clone the repository: `git clone https://github.com/worldskills/worldskills-code-snippets.git`
2. Open the folder in VS Code
3. Press `F5` to open Extension Development Host
4. The extension will be loaded in the new window

## Usage

### Using Snippets

1. Open a file in the appropriate language (PHP, HTML, CSS, JavaScript, or SQL)
2. Type a snippet prefix (e.g., `dbxampp`, `apilogin`, `bs5-container`)
3. Press `Tab` or `Enter` to expand the snippet
4. Fill in placeholders using `Tab` to navigate between them
5. Press `Esc` to exit snippet editing mode

### Example: Database Connection

In a PHP file, type `dbxampp` and press `Tab`:

```php
<?php
$host     = 'localhost';
$port     = '3306';
$dbname   = 'worldskills_db';
$username = 'root';
$password = '';
$charset  = 'utf8mb4';

$dsn = 'mysql:host=' . $host . ';port=' . $port . ';dbname=' . $dbname . ';charset=' . $charset;

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}
```

### Example: Bootstrap Grid

In an HTML file, type `bs5-grid` and press `Tab`:

```html
<div class="row">
    <div class="col-md-6">Column 1</div>
    <div class="col-md-6">Column 2</div>
</div>
```

### Example: Fetch API

In a JavaScript file, type `fetchget` and press `Tab`:

```javascript
async function getData() {
    try {
        const response = await fetch('api/endpoint');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
    }
}
```

## Folder Structure

The extension follows a clean, organized structure:

```
worldskills-code-snippets/
├── .github/
│   └── workflows/
│       └── publish.yml          # GitHub Actions for publishing
├── images/
│   ├── icon.png                  # Extension icon (128x128)
│   ├── logo.png                  # Logo for marketplace
│   └── banner.png                # Banner for marketplace
├── snippets/
│   └── worldskills.code-snippets # Main snippets file
├── .gitignore                    # Git ignore rules
├── .vscodeignore                 # VS Code packaging ignore rules
├── CHANGELOG.md                  # Version history
├── LICENSE                       # MIT License
├── package.json                  # Extension manifest
└── README.md                     # This file
```

## Examples

### PHP Authentication System

```php
// Login API - Type: apilogin
<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/response.php';

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

$stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    json_error('Invalid username or password', 401);
}

$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role'] = $user['role'];

json_success(['user' => ['id' => $user['id'], 'username' => $user['username'], 'role' => $user['role']]]);
```

### Bootstrap 5 Navbar

```html
<!-- Type: navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="#">Brand</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#">About</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>
```

### CSS Variables

```css
/* Type: variables */
:root {
    --color-primary: #007bff;
    --color-secondary: #6c757d;
    --color-success: #28a745;
    --color-danger: #dc3545;
    --color-warning: #ffc107;
    --color-light: #f8f9fa;
    --color-dark: #343a40;
    --font-family: system-ui, sans-serif;
    --border-radius: 4px;
}
```

## Screenshots

### Extension Icon
![Extension Icon](images/icon.png)

### Marketplace Banner
![Marketplace Banner](images/banner.png)

### Snippet in Action
*Screenshot showing snippet expansion in VS Code*
*(Placeholder - add actual screenshot)*

## Snippet Categories

### Database & PDO
- `dbxampp` - Database connection for XAMPP
- `pdo select` - PDO SELECT query
- `pdo insert` - PDO INSERT query
- `pdo update` - PDO UPDATE query
- `pdo delete` - PDO DELETE query
- `count` - COUNT query
- `exists` - Check if record exists
- `dynamic where` - Dynamic WHERE builder
- `dynamic update` - Dynamic UPDATE builder
- `soft delete` - Soft delete with timestamp
- `bulk insert` - Bulk insert multiple records

### HTML & Bootstrap
- `header` - Header section
- `navbar` - Bootstrap navbar
- `sidebar` - Sidebar layout
- `card` - Card component
- `modal` - Modal dialog
- `toast` - Toast notification
- `alert` - Alert message
- `table` - Responsive table
- `form` - Form with validation
- `bs5-container` - Bootstrap container
- `bs5-grid` - Bootstrap grid
- `bs5-accordion` - Bootstrap accordion
- `bs5-carousel` - Bootstrap carousel
- `bs5-dropdown` - Bootstrap dropdown
- `bs5-collapse` - Bootstrap collapse
- `bs5-breadcrumb` - Bootstrap breadcrumb
- `bs5-pagination` - Bootstrap pagination

### CSS
- `reset` - CSS reset
- `variables` - CSS custom properties
- `flex` - Flexbox layout
- `grid` - CSS Grid layout
- `container` - Container CSS
- `navbar css` - Navbar styling
- `sidebar css` - Sidebar styling
- `card css` - Card styling
- `table css` - Table styling
- `toast css` - Toast styling
- `transition` - CSS transition

### JavaScript
- `fetchget` - Fetch GET request
- `fetchpost` - Fetch POST request
- `fetch PUT` - Fetch PUT request
- `fetch DELETE` - Fetch DELETE request
- `querySelector` - Select element
- `debounce` - Debounce function
- `throttle` - Throttle function
- `dark mode` - Dark mode toggle
- `toast notification` - Toast function
- `image preview` - Image preview
- `drag drop` - Drag and drop
- `clipboard copy` - Copy to clipboard
- `download` - Download file

### PHP
- `session start` - Start session
- `session destroy` - Destroy session
- `session get` - Get session value
- `session set` - Set session value
- `session flash` - Flash message
- `csrf token` - CSRF protection
- `password hash` - Hash password
- `password verify` - Verify password
- `autoload` - Class autoloader
- `namespace` - Namespace class
- `mail` - Send email
- `uuid` - Generate UUID
- `slug` - Create slug
- `date helper` - Date functions
- `error handler` - Error handling
- `logger` - Logging function
- `debug` - Debug function
- `dd` - Dump and die
- `dump` - Dump variable

### Authentication
- `authcheck` - Check authentication
- `rolecheck` - Check role
- `readonlycheck` - Enforce read-only
- `sessionguard` - Guard session
- `ipcheck` - IP restriction
- `login` - Login form
- `logout` - Logout handler

### API
- `apiresponse` - Response helpers
- `json response` - JSON output
- `success response` - Success response
- `error response` - Error response
- `apilogin` - Login API
- `apilogout` - Logout API
- `apiconfig` - Config API
- `apitasks` - Tasks API
- `apistatistics` - Statistics API
- `apireport` - Report API

### SQL
- `create database` - Create database
- `create table` - Create table
- `drop database` - Drop database
- `alter table` - Alter table
- `foreign key` - Foreign key
- `index` - Create index
- `unique` - Unique constraint
- `check` - Check constraint
- `having` - HAVING clause
- `procedure` - Stored procedure
- `seed` - Seed data
- `join` - Join tables
- `view` - Create view
- `trigger` - Create trigger

### Security
- `xss` - XSS protection
- `sql injection` - SQL injection protection
- `rate limit` - Rate limiting
- `session timeout` - Session timeout
- `validate` - Input validation

### Dashboard
- `dashboard` - Dashboard layout
- `dashboard statistics` - Statistics cards
- `upload` - File upload

### WorldSkills
- `project structure` - Project folder structure
- `mvc structure` - MVC folder structure
- `constants` - Application constants
- `installer` - Installation script

## Popular Prefixes

### Most Used Snippets

1. `dbxampp` - Database connection
2. `apilogin` - Login API
3. `fetchget` - Fetch GET request
4. `bs5-container` - Bootstrap container
5. `navbar` - Bootstrap navbar
6. `card` - Card component
7. `pdo select` - PDO SELECT
8. `authcheck` - Authentication check
9. `variables` - CSS variables
10. `session start` - Start session

### Quick Reference

| Category | Prefix | Description |
|----------|--------|-------------|
| Database | dbxampp | PDO connection |
| API | apilogin | Login endpoint |
| API | apiresponse | JSON helpers |
| Auth | authcheck | Check login |
| Bootstrap | bs5-container | Container |
| Bootstrap | bs5-grid | Grid layout |
| JavaScript | fetchget | GET request |
| JavaScript | fetchpost | POST request |
| CSS | variables | CSS variables |
| CSS | reset | CSS reset |
| PHP | session start | Start session |
| PHP | password hash | Hash password |
| SQL | create table | Create table |
| SQL | select | Select query |

## FAQ

### Frequently Asked Questions

**Q: How do I install the extension?**

A: Open VS Code, press `Ctrl + Shift + X`, search for "WorldSkills Code Snippets", and click Install.

**Q: Why aren't snippets appearing?**

A: Ensure you're in the correct file type (PHP for PHP snippets, HTML for HTML snippets, etc.) and that the extension is enabled.

**Q: Can I customize the snippets?**

A: Yes! You can modify the snippets file in the extension folder or create your own global snippets.

**Q: Is this extension free?**

A: Yes, this extension is completely free and open-source under the MIT License.

**Q: Can I use this in commercial projects?**

A: Absolutely! The MIT License allows commercial use, modification, and distribution.

**Q: How do I report a bug or request a feature?**

A: Please open an issue on our GitHub repository: https://github.com/worldskills/worldskills-code-snippets/issues

**Q: What VS Code version is required?**

A: This extension requires VS Code version 1.60.0 or higher.

**Q: Are the snippets compatible with PHP 8?**

A: Yes, all PHP snippets are compatible with PHP 8 and follow modern PHP best practices.

**Q: Can I contribute new snippets?**

A: Yes! Contributions are welcome. Please submit a pull request with your snippets.

**Q: How often is the extension updated?**

A: We update the extension regularly with new snippets, bug fixes, and improvements.

## Troubleshooting

### Common Issues and Solutions

#### Snippets Not Appearing

**Problem**: You type a snippet prefix but nothing appears.

**Solutions**:
1. Check that you're in the correct file type (PHP, HTML, CSS, JavaScript, SQL)
2. Reload VS Code (`Ctrl + Shift + P` → "Developer: Reload Window")
3. Verify the extension is enabled in Extensions view
4. Try triggering IntelliSense manually with `Ctrl + Space`

#### JSON Errors

**Problem**: VS Code shows JSON syntax errors in the snippets file.

**Solutions**:
1. Check for missing commas after JSON properties
2. Remove trailing commas (not allowed in JSON)
3. Ensure all strings are properly quoted
4. Use a JSON validator to check the file

#### Wrong Language Mode

**Problem**: Snippets appear in wrong file types or not at all.

**Solutions**:
1. Check the language mode in the bottom-right corner of VS Code
2. Click the language indicator and select the correct language
3. Force language mode with `Ctrl + K`, then `M`

#### Duplicate Prefixes

**Problem**: Multiple snippets with same prefix cause conflicts.

**Solutions**:
1. Open the snippets file
2. Search for duplicate prefix values
3. Rename conflicting prefixes to be more specific
4. Use scope to differentiate (e.g., same prefix for different languages)

#### Extension Not Loading

**Problem**: Extension doesn't load after installation.

**Solutions**:
1. Reload VS Code completely
2. Disable and re-enable the extension
3. Check VS Code version compatibility (requires 1.60.0+)
4. Check VS Code output panel for error messages

## Contributing

We welcome contributions from the community! Here's how you can help:

### How to Contribute

1. **Fork the Repository**
   ```bash
   git clone https://github.com/worldskills/worldskills-code-snippets.git
   ```

2. **Create a Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make Your Changes**
   - Add new snippets following the existing format
   - Ensure JSON is valid
   - Test snippets in VS Code
   - Update documentation if needed

4. **Commit Your Changes**
   ```bash
   git commit -m "Add your commit message"
   ```

5. **Push to Your Branch**
   ```bash
   git push origin feature/your-feature-name
   ```

6. **Submit a Pull Request**
   - Go to the repository on GitHub
   - Click "New Pull Request"
   - Describe your changes
   - Submit for review

### Contribution Guidelines

- **Snippets**: Keep snippets between 10-40 lines
- **Descriptions**: Use clear, concise English descriptions
- **Prefixes**: Use lowercase, descriptive prefixes
- **Placeholders**: Include helpful default values
- **Testing**: Test all snippets before submitting
- **Documentation**: Update README if adding new categories

### Code of Conduct

Please be respectful and constructive in all interactions. We value diversity and inclusion.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

### MIT License

Copyright (c) 2026 WorldSkills Web Technologies

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Acknowledgments

- **WorldSkills International** - For inspiring this extension
- **VS Code Team** - For the excellent extension API
- **Community Contributors** - For snippets, feedback, and improvements

## Support

- **GitHub Issues**: https://github.com/worldskills/worldskills-code-snippets/issues
- **Documentation**: https://github.com/worldskills/worldskills-code-snippets/wiki
- **Discussions**: https://github.com/worldskills/worldskills-code-snippets/discussions

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history and updates.

---

**Made with ❤️ for WorldSkills Web Technologies**

Happy coding! 🚀
