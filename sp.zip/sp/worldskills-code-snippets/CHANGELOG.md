# Changelog

All notable changes to the WorldSkills Code Snippets extension will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-07-07

### Added
- Initial release of WorldSkills Code Snippets extension
- 100+ production-ready code snippets
- PHP snippets including:
  - Database connection for XAMPP
  - API response helpers (success, error, forbidden)
  - Authentication checks (auth, role, read-only, session guard)
  - IP/VPN restriction
  - Login/logout pages and APIs
  - Session management
  - Password hashing and verification
  - CSRF token generation
  - Error handling and logging
  - UUID generation
  - Slug creation
  - Date helpers
  - Email sending
  - Class autoloader
  - Namespace support
- HTML snippets including:
  - Semantic HTML5 templates
  - Header section with navigation
  - Pricing card component
  - FAQ section
  - Search form
  - 404 and 500 error pages
  - Login form with WCAG accessibility
  - Dashboard router
- Bootstrap 5 snippets including:
  - Container
  - Grid layout
  - Accordion
  - Carousel
  - Dropdown
  - Collapse
  - Breadcrumb
  - Pagination
  - Navbar
  - Sidebar
  - Card
  - Modal
  - Toast
  - Alert
  - Table
  - Form
  - Offcanvas
- CSS snippets including:
  - CSS reset
  - Custom properties (variables)
  - Flexbox layout
  - Grid layout
  - Container styling
  - Navbar styling
  - Sidebar styling
  - Card styling
  - Table styling
  - Toast styling
  - Loading spinner
  - Transition effects
  - Accessible responsive CSS
- JavaScript snippets including:
  - Fetch API wrappers (GET, POST, PUT, DELETE)
  - Query selector
  - Debounce function
  - Throttle function
  - Dark mode toggle
  - AJAX helper
  - Fetch wrapper with error handling
  - Toast notification
  - Image preview
  - Drag and drop file upload
  - Clipboard copy
  - File download
- PDO snippets including:
  - SELECT, INSERT, UPDATE, DELETE queries
  - COUNT query
  - Record existence check
  - Dynamic WHERE clause builder
  - Dynamic UPDATE builder
  - Soft delete implementation
  - Bulk insert operations
- SQL snippets including:
  - Create database
  - Create table
  - Drop database
  - Alter table
  - Foreign key constraints
  - Index creation
  - Unique constraints
  - Check constraints
  - HAVING clause
  - Stored procedures
  - Seed data
  - JOIN queries
  - Views
  - Triggers
  - GROUP BY
  - ORDER BY
- Security snippets including:
  - XSS protection
  - SQL injection protection
  - Rate limiting
  - Session timeout
  - Input validation
- Dashboard snippets including:
  - Statistics cards
  - Dashboard layout
- WorldSkills-specific snippets including:
  - Project folder structure
  - MVC folder structure
  - Application constants
  - Installation script
- Complete documentation with README
- MIT License
- Package.json with proper metadata
- GitHub Actions workflow for automated publishing
- VS Code packaging configuration

### Features
- Multi-language support (PHP, HTML, CSS, JavaScript, SQL)
- Production-ready code following best practices
- WorldSkills competition-ready patterns
- Comprehensive documentation
- Easy installation from VS Code Marketplace
- Regular updates and maintenance

### Documentation
- Complete README with installation guide
- Usage examples for all categories
- Troubleshooting section
- FAQ section
- Contributing guidelines
- License information

## [Unreleased]

### Planned
- TypeScript snippets
- Vue.js snippets
- React snippets
- Laravel snippets
- WordPress snippets
- Additional security patterns
- More database utilities
- Enhanced testing snippets

---

[1.0.0]: https://github.com/worldskills/worldskills-code-snippets/releases/tag/v1.0.0
