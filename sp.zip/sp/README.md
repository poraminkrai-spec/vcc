# WorldSkills Code Snippets

A comprehensive collection of Visual Studio Code code snippets designed specifically for WorldSkills Web Technologies competition participants and developers. This snippets collection accelerates development by providing ready-to-use code templates for common web development tasks.

## Purpose

This snippets collection is designed for:

- **WorldSkills Web Technologies** - Competition-ready code following best practices and standards
- **Fast Development** - Reduce typing time and focus on logic instead of boilerplate
- **PHP** - Server-side scripting with PDO, authentication, session management, and API development
- **HTML** - Semantic markup, forms, tables, and accessible components
- **CSS** - Responsive layouts, flexbox, grid, animations, and modern styling
- **JavaScript** - DOM manipulation, fetch API, event handling, and client-side utilities
- **Bootstrap 5** - Pre-built components, grid system, and responsive design patterns
- **PDO** - Secure database operations with prepared statements and error handling
- **CRUD** - Create, Read, Update, Delete operations with proper validation
- **SQL** - Database schema creation, queries, joins, and optimization
- **Authentication** - Login, logout, role-based access control, and session management
- **API** - RESTful endpoints with JSON responses and proper HTTP status codes

## Why Use These Snippets?

WorldSkills competitions require participants to build complete web applications within strict time limits. These snippets help you:

- **Save Time** - Insert complex code patterns with a few keystrokes
- **Maintain Consistency** - Follow established coding patterns throughout your project
- **Learn Best Practices** - Each snippet demonstrates professional coding standards
- **Reduce Errors** - Pre-validated code with proper error handling and security measures
- **Focus on Logic** - Spend less time on boilerplate and more on solving problems

# Installation Guide

Follow these steps to install the WorldSkills code snippets in Visual Studio Code.

## Step 1: Open Visual Studio Code

Launch VS Code on your computer. Ensure you have the latest version installed for the best experience.

## Step 2: Open Command Palette

Press the following keyboard shortcut:

```
Ctrl + Shift + P
```

This will open the Command Palette at the top of the VS Code window.

## Step 3: Search for Snippets Configuration

Type the following command in the search box:

```
Snippets: Configure Snippets
```

Press **Enter** to execute the command.

## Step 4: Create or Open Snippets File

A dropdown menu will appear showing available snippet files. You have two options:

### Option A: Creating a New Snippets File

If you do not have a `worldskills.code-snippets` file:

1. Choose **"New Global Snippets file"** from the dropdown
2. VS Code will prompt you to name the file
3. Type: `worldskills`
4. Press **Enter**
5. VS Code will create and open `worldskills.code-snippets` in a new editor tab

### Option B: Opening Existing Snippets File

If you already have a `worldskills.code-snippets` file:

1. Select **"worldskills.code-snippets"** from the dropdown list
2. VS Code will open the existing file in an editor tab

## Step 5: Replace Snippets Content

Now you need to replace the content of the snippets file with the new WorldSkills snippets:

1. Press **Ctrl + A** to select all existing content in the file
2. Press **Delete** or **Backspace** to remove all existing content
3. Copy the entire content from the provided `worldskills.code-snippets` file
4. Press **Ctrl + V** to paste the new snippets into the file
5. Press **Ctrl + S** to save the file

## Step 6: Reload VS Code

To ensure the snippets are properly loaded, reload VS Code:

1. Press **Ctrl + Shift + P** to open the Command Palette
2. Type: **"Developer: Reload Window"**
3. Press **Enter**
4. VS Code will restart and load the new snippets

## Verification

To verify the installation:

1. Create a new file (e.g., `test.php`)
2. Type a snippet prefix (e.g., `dbxampp`)
3. Press **Tab** or **Enter**
4. The snippet should expand with the full code template

If the snippet does not appear, ensure you are in the correct language mode (PHP for PHP snippets, HTML for HTML snippets, etc.).

# Folder Structure

A well-organized project structure is essential for WorldSkills competitions and professional development. Below is a recommended professional WorldSkills project structure.

## Recommended Structure

```
project/
├── assets/
│   ├── css/
│   │   ├── bootstrap/
│   │   ├── style.css
│   │   └── custom.css
│   ├── images/
│   │   ├── icons/
│   │   └── uploads/
│   ├── fonts/
│   └── js/
│       ├── modules/
│       └── main.js
├── pages/
│   ├── index.php
│   ├── login.php
│   ├── logout.php
│   ├── dashboard.php
│   └── error/
│       ├── 404.php
│       └── 500.php
├── uploads/
├── api/
│   ├── auth/
│   │   ├── login.php
│   │   └── logout.php
│   ├── users/
│   ├── submissions/
│   └── statistics.php
├── config/
│   ├── db.php
│   ├── constants.php
│   └── routes.php
├── database/
│   ├── migrations/
│   └── seeds/
├── helpers/
│   ├── auth.php
│   ├── validation.php
│   └── response.php
├── middleware/
│   ├── auth-check.php
│   ├── role-check.php
│   └── session-guard.php
├── models/
│   ├── User.php
│   ├── Submission.php
│   └── Result.php
├── controllers/
│   ├── AuthController.php
│   ├── DashboardController.php
│   └── SubmissionController.php
├── views/
│   ├── layouts/
│   │   ├── header.php
│   │   └── footer.php
│   ├── auth/
│   │   └── login.php
│   └── dashboard/
│       └── index.php
├── includes/
│   ├── header.php
│   ├── footer.php
│   └── functions.php
├── templates/
├── vendor/
├── logs/
│   ├── app.log
│   └── error.log
├── sql/
│   ├── schema.sql
│   └── data.sql
├── index.php
├── README.md
└── worldskills.code-snippets
```

## Folder Explanations

### assets/
Contains all static assets used by the application.

- **css/** - Stylesheets including Bootstrap framework and custom styles
- **images/** - Image files organized by type (icons, uploads)
- **fonts/** - Custom font files
- **js/** - JavaScript files and modules

### pages/
Public-facing pages accessible via browser.

- **index.php** - Main landing page
- **login.php** - User authentication page
- **logout.php** - Logout handler
- **dashboard.php** - Main dashboard router
- **error/** - Custom error pages (404, 500)

### uploads/
Directory for user-uploaded files (images, documents). Ensure proper permissions and security measures.

### api/
RESTful API endpoints for client-server communication.

- **auth/** - Authentication endpoints (login, logout)
- **users/** - User management endpoints
- **submissions/** - Submission CRUD operations
- **statistics.php** - Statistics and reporting endpoints

### config/
Configuration files for database, constants, and application settings.

- **db.php** - Database connection using PDO
- **constants.php** - Application-wide constants
- **routes.php** - URL routing configuration

### database/
Database-related files including migrations and seed data.

- **migrations/** - Database schema version control
- **seeds/** - Initial data for testing

### helpers/
Reusable helper functions for common tasks.

- **auth.php** - Authentication helper functions
- **validation.php** - Input validation functions
- **response.php** - JSON response formatting

### middleware/
Request processing middleware for authentication, authorization, and validation.

- **auth-check.php** - Verify user is logged in
- **role-check.php** - Verify user has required role
- **session-guard.php** - Check session status

### models/
Data models representing database entities with business logic.

- **User.php** - User model with authentication methods
- **Submission.php** - Submission model with CRUD operations
- **Result.php** - Result model with scoring logic

### controllers/
Request handlers that coordinate between models and views.

- **AuthController.php** - Handle authentication requests
- **DashboardController.php** - Handle dashboard data
- **SubmissionController.php** - Handle submission operations

### views/
Presentation layer using PHP templates.

- **layouts/** - Reusable layout templates (header, footer)
- **auth/** - Authentication-related views
- **dashboard/** - Dashboard views

### includes/
Common include files used across the application.

- **header.php** - Page header with navigation
- **footer.php** - Page footer with scripts
- **functions.php** - Global utility functions

### templates/
Template files for emails, PDFs, or other generated content.

### vendor/
Third-party libraries and dependencies (managed by Composer).

### logs/
Application log files for debugging and monitoring.

- **app.log** - General application logs
- **error.log** - Error-specific logs

### sql/
Raw SQL scripts for database setup and maintenance.

- **schema.sql** - Database schema creation
- **data.sql** - Sample data insertion

# How To Use Snippets

Understanding how VS Code snippets work will help you use them effectively.

## What Are Snippets?

Snippets are reusable code templates that you can insert into your files by typing a short prefix. They save time and ensure consistency across your codebase.

## Tab Stops

Tab stops are positions within a snippet where your cursor will move when you press the **Tab** key. They are numbered sequentially starting from 1.

Example:
```php
$host = '${1:localhost}';
$port = '${2:3306}';
```

When you insert this snippet:
1. Your cursor starts at `${1:localhost}`
2. Type your value and press **Tab**
3. Cursor moves to `${2:3306}`
4. Continue until all tab stops are filled
5. Final `$0` position is where cursor ends

## Placeholder Variables

Placeholders are default values that appear in tab stops. They are shown in the format `${n:default_value}` where:
- `n` is the tab stop number
- `default_value` is the suggested text

You can:
- Accept the default by pressing **Tab**
- Replace it by typing your own value
- Delete it and leave it empty

## Prefix

The prefix is the short keyword you type to trigger a snippet. For example:
- Type `dbxampp` in a PHP file
- Press **Tab** or **Enter**
- The database connection snippet expands

## Scope

The scope determines in which file types a snippet is available. Common scopes include:
- `php` - Only in PHP files
- `html` - Only in HTML files
- `css` - Only in CSS files
- `javascript` - Only in JavaScript files
- `sql` - Only in SQL files

If a snippet doesn't appear, check that you're in the correct file type for its scope.

## JSON Snippets Format

Snippets are stored in JSON format with the following structure:

```json
{
  "Snippet Name": {
    "prefix": "trigger-word",
    "scope": "language",
    "body": [
      "line 1",
      "line 2",
      "${1:placeholder}"
    ],
    "description": "What this snippet does"
  }
}
```

- **Snippet Name** - Display name in IntelliSense
- **prefix** - Keyword to trigger the snippet
- **scope** - File types where snippet works
- **body** - Array of code lines (use `\\$` for literal `$` in PHP)
- **description** - Tooltip text shown when hovering

## Using Snippets

1. Open a file in the appropriate language (PHP, HTML, CSS, etc.)
2. Type the snippet prefix
3. Press **Tab** or **Enter** to expand
4. Fill in placeholders using **Tab** to navigate
5. Press **Esc** to exit snippet editing mode

## Tips for Efficient Snippet Usage

- **Learn Common Prefixes** - Memorize frequently used snippet prefixes
- **Use IntelliSense** - Press **Ctrl + Space** to see available snippets
- **Customize Snippets** - Modify the snippets file to add your own
- **Organize by Category** - Group related snippets mentally for easier recall
- **Practice** - Regular use builds muscle memory for common patterns

# Complete Snippet List

Below is a comprehensive table of all available snippets in the WorldSkills collection.

| Category | Prefix | Description | Example |
|----------|--------|-------------|---------|
| **Database** | dbxampp | PDO connection for XAMPP MySQL | `$pdo = new PDO($dsn, $username, $password, $options);` |
| **API** | apiresponse | JSON response helpers (success, error, forbidden) | `json_success($data, $meta, 200);` |
| **Auth** | authcheck | Check if user is logged in | `if (empty($_SESSION['user_id'])) json_error('Unauthorized', 401);` |
| **Auth** | rolecheck | Require specific user role | `require_role(['admin', 'manager']);` |
| **Auth** | readonlycheck | Enforce read-only access for specific roles | `enforce_readonly(['manager']);` |
| **Session** | sessionguard | Check if review session is open | `require_session_open();` |
| **Security** | ipcheck | IP/VPN restriction for internal network | `check_ip_allowed(['192.168.1.0/24']);` |
| **Pages** | pagelogin | Login page with WCAG accessibility | `<form id="loginForm">...</form>` |
| **Pages** | pagedashboard | Dashboard router based on user role | `switch ($_SESSION['role']) { ... }` |
| **API** | apilogin | Login API with password verification | `password_verify($password, $user['password'])` |
| **API** | apilogout | Logout API destroying session | `session_unset(); session_destroy();` |
| **API** | apiconfig | Config API returning session status | `json_success(['session_status' => $status]);` |
| **API** | apitasks | Tasks API returning all tasks | `json_success($tasks, ['total' => count($tasks)]);` |
| **API** | apimysubmission | My submission API (GET/POST/PUT) | Handle frontend/backend URL submission |
| **API** | apimyresult | My result API for candidate scores | `SELECT * FROM results WHERE user_id = ?` |
| **API** | apicandidates | Candidates list API for judges | `SELECT * FROM users WHERE role = 'candidate'` |
| **API** | apisubmissions | Submissions list API for judges | `SELECT s.*, u.username FROM submissions s JOIN users u` |
| **API** | apisessionstart | Session start API (PUT) for judges | `UPDATE review_sessions SET status = 'open'` |
| **API** | apisessionclose | Session close API (PUT) for judges | `UPDATE review_sessions SET status = 'closed'` |
| **API** | apirecheck | Recheck submission API (POST) | `UPDATE submissions SET status = 'pending_recheck'` |
| **API** | apiconfirm | Confirm result API (PUT) with auto-pass | `UPDATE results SET passed = ? WHERE score >= 60` |
| **API** | apistatistics | Statistics API (summary/ranking/status) | Multiple query types with ?type parameter |
| **API** | apireport | Report API for export | `json_success($report, ['generated_at' => date('Y-m-d H:i:s')]);` |
| **Pages** | pagecandidatedash | Candidate dashboard with countdown timer | Real-time countdown to submission deadline |
| **Pages** | pagejudgedash | Judge dashboard with session controls | Start/close session, recheck, confirm results |
| **Pages** | pagemanagerdash | Manager dashboard with statistics | Read-only view of rankings and reports |
| **CSS** | csswcag | Accessible responsive CSS with WCAG | Focus states, responsive media queries |
| **CSS** | card css | Card component CSS | Border, padding, shadow, border-radius |
| **CSS** | navbar css | Navbar component CSS | Flexbox navigation with responsive design |
| **CSS** | table css | Table component CSS | Striped rows, hover effects, responsive |
| **CSS** | sidebar css | Sidebar component CSS | Fixed position, smooth transitions |
| **CSS** | loading css | Loading spinner CSS | Animation keyframes for spinner |
| **HTML** | navbar | Bootstrap 5 navbar | Responsive navigation with collapse |
| **HTML** | sidebar | Sidebar layout with toggle | Offcanvas-style sidebar component |
| **HTML** | card | Card component with header/body/footer | Bootstrap 5 card structure |
| **HTML** | modal | Bootstrap 5 modal dialog | Modal with header, body, footer |
| **HTML** | toast | Bootstrap 5 toast notification | Auto-dismissing toast messages |
| **HTML** | alert | Bootstrap 5 alert messages | Success, danger, warning, info alerts |
| **HTML** | table | Bootstrap 5 responsive table | Striped, bordered, hoverable table |
| **HTML** | form | Bootstrap 5 form with validation | Input fields with labels and validation |
| **HTML** | login | Login form with accessibility | WCAG-compliant login form |
| **HTML** | dashboard | Dashboard layout with sidebar | Main dashboard structure |
| **HTML** | offcanvas | Bootstrap 5 offcanvas component | Slide-in panel for mobile menus |
| **JavaScript** | fetch GET | Fetch API GET request | `async function getData() { const r = await fetch(url); }` |
| **JavaScript** | fetch POST | Fetch API POST request | `await fetch(url, { method: 'POST', body: JSON.stringify(data) });` |
| **JavaScript** | debounce | Debounce function for events | Delay function execution until pause |
| **JavaScript** | throttle | Throttle function for events | Limit function execution frequency |
| **JavaScript** | dark mode | Dark mode toggle with localStorage | Theme persistence across sessions |
| **JavaScript** | ajax helper | AJAX helper function | Simplified fetch wrapper |
| **JavaScript** | fetch wrapper | Fetch wrapper with error handling | Centralized API call handling |
| **PHP** | session start | Session start with security | Secure session configuration |
| **PHP** | session destroy | Session destroy and cleanup | Complete session cleanup |
| **PHP** | session get | Get session variable safely | Safe session value retrieval |
| **PHP** | session set | Set session variable safely | Safe session value assignment |
| **PHP** | session flash | Flash message for next request | One-time session messages |
| **PHP** | csrf token | CSRF token generation and validation | Cross-site request forgery protection |
| **PHP** | password hash | Password hashing with bcrypt | `password_hash($password, PASSWORD_DEFAULT)` |
| **PHP** | password verify | Password verification | `password_verify($password, $hash)` |
| **PHP** | try catch | Try-catch error handling | Exception handling block |
| **PHP** | pdo select | PDO SELECT query | Prepared statement for SELECT |
| **PHP** | pdo insert | PDO INSERT query | Prepared statement for INSERT |
| **PHP** | pdo update | PDO UPDATE query | Prepared statement for UPDATE |
| **PHP** | pdo delete | PDO DELETE query | Prepared statement for DELETE |
| **PHP** | debug | Debug function with var_dump | Development debugging helper |
| **PHP** | dd | Dump and die function | Debug and terminate execution |
| **PHP** | dump | Dump variable | Pretty-print variables |
| **PHP** | json response | JSON response helper | Standardized JSON output |
| **PHP** | success response | Success response function | HTTP 200 with success data |
| **PHP** | error response | Error response function | HTTP error with message |
| **SQL** | create database | Create database with charset | UTF-8 database creation |
| **SQL** | create table | Create table with columns | Table structure definition |
| **SQL** | foreign key | Add foreign key constraint | Referential integrity |
| **SQL** | insert | Insert single record | Single row insertion |
| **SQL** | update | Update record | Update existing data |
| **SQL** | delete | Delete record | Remove data |
| **SQL** | select | Select query | Data retrieval |
| **SQL** | join | Inner join query | Table joining |
| **SQL** | left join | Left join query | Left outer join |
| **SQL** | view | Create view | Virtual table |
| **SQL** | trigger | Create trigger | Automatic action on event |
| **SQL** | group by | Group by aggregation | Data grouping |
| **SQL** | order by | Order by sorting | Result sorting |
| **HTML** | header | Header section with logo and navigation | `<header><nav>...</nav></header>` |
| **HTML** | pricing | Pricing card component | Pricing table with features |
| **HTML** | faq | FAQ section with questions and answers | Accordion-style FAQ |
| **HTML** | search form | Search form with query input | GET method search form |
| **HTML** | 404 page | 404 error page | Custom not found page |
| **HTML** | 500 page | 500 error page | Custom server error page |
| **CSS** | reset | CSS reset for consistent styling | Normalize browser defaults |
| **CSS** | variables | CSS custom properties (variables) | `:root { --color-primary: #007bff; }` |
| **CSS** | container | Container CSS with max-width | Responsive container |
| **CSS** | toast css | Toast notification CSS | Fixed position toast |
| **CSS** | transition | CSS transition property | Smooth state changes |
| **Bootstrap** | bs5-container | Bootstrap 5 container | `<div class="container"></div>` |
| **Bootstrap** | bs5-grid | Bootstrap 5 grid layout | Row and column structure |
| **Bootstrap** | bs5-accordion | Bootstrap 5 accordion component | Collapsible content panels |
| **Bootstrap** | bs5-carousel | Bootstrap 5 carousel slider | Image slideshow |
| **Bootstrap** | bs5-dropdown | Bootstrap 5 dropdown menu | Dropdown with items |
| **Bootstrap** | bs5-collapse | Bootstrap 5 collapse component | Show/hide content |
| **Bootstrap** | bs5-breadcrumb | Bootstrap 5 breadcrumb navigation | Breadcrumb trail |
| **Bootstrap** | bs5-pagination | Bootstrap 5 pagination | Page navigation |
| **JavaScript** | querySelector | Select element with querySelector | `const element = document.querySelector('.selector');` |
| **JavaScript** | fetch PUT | Fetch API PUT request | Update data via API |
| **JavaScript** | fetch DELETE | Fetch API DELETE request | Delete data via API |
| **JavaScript** | toast notification | Toast notification function | Dynamic toast messages |
| **JavaScript** | image preview | Image preview before upload | FileReader for image preview |
| **JavaScript** | drag drop | Drag and drop file upload | Drag-and-drop zone |
| **JavaScript** | clipboard copy | Copy text to clipboard | `navigator.clipboard.writeText()` |
| **JavaScript** | download | Download file from URL | Programmatic file download |
| **PHP** | autoload | PHP class autoloader | `spl_autoload_register()` |
| **PHP** | namespace | PHP namespace class | Namespaced class structure |
| **PHP** | mail | PHP mail function | Email sending |
| **PHP** | uuid | Generate UUID v4 | Unique identifier generation |
| **PHP** | slug | Create URL-friendly slug | String to slug conversion |
| **PHP** | date helper | PHP date helper functions | formatDate and timeAgo |
| **PHP** | error handler | PHP error and exception handler | Custom error handling |
| **PHP** | logger | Simple PHP logger function | File-based logging |
| **PDO** | count | PDO COUNT query | Count records |
| **PDO** | exists | PDO check if record exists | Record existence check |
| **PDO** | dynamic where | PDO dynamic WHERE clause builder | Conditional query building |
| **PDO** | dynamic update | PDO dynamic UPDATE builder | Dynamic update construction |
| **PDO** | soft delete | PDO soft delete with timestamp | Mark as deleted |
| **PDO** | bulk insert | PDO bulk insert multiple records | Batch insertion |
| **CRUD** | crud store | CRUD store API endpoint | Create record API |
| **CRUD** | crud destroy | CRUD destroy API endpoint | Delete record API |
| **SQL** | drop database | Drop database | Database removal |
| **SQL** | alter table | Add column to table | Schema modification |
| **SQL** | index | Create index on column | Performance optimization |
| **SQL** | unique | Add unique constraint | Data uniqueness |
| **SQL** | check | Add check constraint | Data validation |
| **SQL** | having | SQL HAVING clause | Group filtering |
| **SQL** | procedure | Create stored procedure | Database procedure |
| **SQL** | seed | Insert multiple seed records | Test data insertion |
| **Security** | xss | XSS protection with htmlspecialchars | Output escaping |
| **Security** | sql injection | SQL injection protection example | Prepared statement demonstration |
| **Security** | rate limit | Simple rate limiting function | Request throttling |
| **Security** | session timeout | Session timeout with inactivity check | Auto-logout |
| **Dashboard** | dashboard statistics | Dashboard statistics cards | Stat display widgets |
| **WorldSkills** | project structure | WorldSkills project folder structure | Competition-ready layout |
| **WorldSkills** | mvc structure | MVC folder structure | Model-View-Controller pattern |
| **WorldSkills** | constants | Application constants file | Configuration constants |
| **WorldSkills** | installer | WorldSkills installation script | Setup automation |

# Examples

This section provides practical examples for using the most common snippets in real-world scenarios.

## HTML Example

Using the **navbar** snippet to create a responsive navigation bar:

```html
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="#">Brand</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#">About</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>
```

## CSS Example

Using the **card css** snippet to style a card component:

```css
.card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  margin: 15px 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  background-color: #fff;
}

.card:hover {
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
  transition: all 0.3s ease;
}
```

## Bootstrap Example

Using the **bs5-grid** snippet to create a responsive layout:

```html
<div class="container">
  <div class="row">
    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Column 1</h5>
          <p class="card-text">Content for first column</p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Column 2</h5>
          <p class="card-text">Content for second column</p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Column 3</h5>
          <p class="card-text">Content for third column</p>
        </div>
      </div>
    </div>
  </div>
</div>
```

## JavaScript Example

Using the **fetch GET** snippet to retrieve data from an API:

```javascript
async function loadUsers() {
  try {
    const response = await fetch('api/users.php');
    const data = await response.json();
    
    if (data.success) {
      displayUsers(data.data);
    } else {
      console.error('Error:', data.message);
    }
  } catch (error) {
    console.error('Fetch error:', error);
  }
}

function displayUsers(users) {
  const container = document.getElementById('users-container');
  container.innerHTML = users.map(user => `
    <div class="user-card">
      <h3>${user.username}</h3>
      <p>${user.email}</p>
    </div>
  `).join('');
}
```

## PHP Example

Using the **pdo select** snippet to fetch data from the database:

```php
<?php
require_once 'config/db.php';

$stmt = $pdo->prepare('SELECT * FROM users WHERE role = ? ORDER BY created_at DESC');
$stmt->execute(['candidate']);
$users = $stmt->fetchAll();

foreach ($users as $user) {
    echo "<div class='user'>";
    echo "<h3>" . htmlspecialchars($user['username']) . "</h3>";
    echo "<p>" . htmlspecialchars($user['email']) . "</p>";
    echo "</div>";
}
?>
```

## PDO Example

Using the **pdo insert** snippet to add a new record:

```php
<?php
require_once 'config/db.php';

$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if ($username && $email && $password) {
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)');
    $stmt->execute([$username, $email, $hashedPassword, 'candidate']);
    
    echo "User created successfully!";
}
?>
```

## CRUD Example

Using the **crud store** snippet to create a store API endpoint:

```php
<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/response.php';

$input = json_decode(file_get_contents('php://input'), true);

$title = $input['title'] ?? '';
$description = $input['description'] ?? '';

if ($title === '' || $description === '') {
    json_error('Title and description are required', 422);
}

$stmt = $pdo->prepare('INSERT INTO tasks (title, description, status) VALUES (?, ?, ?)');
$stmt->execute([$title, $description, 'pending']);

json_success(['id' => $pdo->lastInsertId(), 'title' => $title], [], 201);
?>
```

## Login Example

Using the **apilogin** snippet to create a login API:

```php
<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/response.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

if ($username === '' || $password === '') {
    json_error('Username and password are required', 422);
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    json_error('Invalid username or password', 401);
}

$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role'] = $user['role'];

json_success(['user' => ['id' => $user['id'], 'username' => $user['username'], 'role' => $user['role']]]);
?>
```

## Register Example

Creating a registration system using multiple snippets:

```php
<?php
require_once 'config/db.php';
require_once 'includes/response.php';

$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Validate input
if ($username === '' || $email === '' || $password === '') {
    json_error('All fields are required', 422);
}

// Check if user exists
$stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
$stmt->execute([$username, $email]);
if ($stmt->fetch()) {
    json_error('Username or email already exists', 409);
}

// Hash password and create user
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)');
$stmt->execute([$username, $email, $hashedPassword, 'candidate']);

json_success(['message' => 'Registration successful'], [], 201);
?>
```

## API Example

Using the **apiresponse** snippet for consistent API responses:

```php
<?php
require_once 'includes/response.php';
require_once 'includes/auth-check.php';

// Success response with data
json_success([
    'users' => $users,
    'total' => count($users)
], [
    'page' => 1,
    'per_page' => 10
]);

// Error response
json_error('User not found', 404);

// Forbidden response
json_forbidden('You do not have permission to access this resource');
?>
```

## Upload Example

Handling file uploads with validation:

```php
<?php
require_once 'config/db.php';
require_once 'includes/response.php';

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    json_error('No file uploaded or upload error', 400);
}

$file = $_FILES['file'];
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];

if (!in_array($file['type'], $allowedTypes)) {
    json_error('Invalid file type. Only JPEG, PNG, and GIF allowed', 422);
}

$maxSize = 5 * 1024 * 1024; // 5MB
if ($file['size'] > $maxSize) {
    json_error('File size exceeds 5MB limit', 422);
}

$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$filename = uniqid() . '_' . basename($file['name']);
$filepath = $uploadDir . $filename;

if (!move_uploaded_file($file['tmp_name'], $filepath)) {
    json_error('Failed to save file', 500);
}

json_success([
    'filename' => $filename,
    'path' => '/uploads/' . $filename,
    'size' => $file['size']
]);
?>
```

## SQL Example

Using the **create table** snippet to define database schema:

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('candidate', 'judge', 'manager') DEFAULT 'candidate',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_id INT NOT NULL,
    frontend_url VARCHAR(255) NOT NULL,
    backend_api_url VARCHAR(255) NOT NULL,
    status ENUM('submitted', 'pending_recheck', 'checked') DEFAULT 'pending_recheck',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## Dashboard Example

Using the **dashboard statistics** snippet to create stat cards:

```html
<div class="statistics">
  <div class="stat-card">
    <h3>Total Users</h3>
    <p class="stat-value">1,234</p>
    <p class="stat-change">+12% from last month</p>
  </div>
  <div class="stat-card">
    <h3>Active Sessions</h3>
    <p class="stat-value">456</p>
    <p class="stat-change">+5% from yesterday</p>
  </div>
  <div class="stat-card">
    <h3>Total Submissions</h3>
    <p class="stat-value">789</p>
    <p class="stat-change">+23% this week</p>
  </div>
  <div class="stat-card">
    <h3>Revenue</h3>
    <p class="stat-value">$12,345</p>
    <p class="stat-change">+8% from last quarter</p>
  </div>
</div>

<style>
.statistics {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin: 20px 0;
}

.stat-card {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.stat-card h3 {
  margin: 0 0 10px 0;
  color: #666;
  font-size: 14px;
}

.stat-value {
  font-size: 32px;
  font-weight: bold;
  color: #333;
  margin: 0 0 5px 0;
}

.stat-change {
  margin: 0;
  font-size: 12px;
  color: #28a745;
}
</style>
```

# Recommended Prefixes

Memorizing these commonly used prefixes will significantly speed up your development workflow.

## Database & PDO

- `dbxampp` - Database connection for XAMPP
- `pdo select` - PDO SELECT query
- `pdo insert` - PDO INSERT query
- `pdo update` - PDO UPDATE query
- `pdo delete` - PDO DELETE query
- `count` - COUNT query
- `exists` - Check if record exists
- `dynamic where` - Dynamic WHERE builder
- `dynamic update` - Dynamic UPDATE builder
- `soft delete` - Soft delete with timestamp
- `bulk insert` - Bulk insert multiple records

## HTML & Bootstrap

- `html` - Basic HTML5 template
- `html5` - HTML5 with meta tags
- `header` - Header section
- `navbar` - Bootstrap navbar
- `sidebar` - Sidebar layout
- `card` - Card component
- `modal` - Modal dialog
- `toast` - Toast notification
- `alert` - Alert message
- `table` - Responsive table
- `form` - Form with validation
- `bs5-container` - Bootstrap container
- `bs5-grid` - Bootstrap grid
- `bs5-accordion` - Bootstrap accordion
- `bs5-carousel` - Bootstrap carousel
- `bs5-dropdown` - Bootstrap dropdown
- `bs5-collapse` - Bootstrap collapse
- `bs5-breadcrumb` - Bootstrap breadcrumb
- `bs5-pagination` - Bootstrap pagination

## CSS

- `css` - Basic CSS template
- `reset` - CSS reset
- `variables` - CSS custom properties
- `flex` - Flexbox layout
- `grid` - CSS Grid layout
- `container` - Container CSS
- `navbar css` - Navbar styling
- `sidebar css` - Sidebar styling
- `card css` - Card styling
- `table css` - Table styling
- `toast css` - Toast styling
- `transition` - CSS transition

## JavaScript

- `fetchget` - Fetch GET request
- `fetchpost` - Fetch POST request
- `fetch PUT` - Fetch PUT request
- `fetch DELETE` - Fetch DELETE request
- `querySelector` - Select element
- `debounce` - Debounce function
- `throttle` - Throttle function
- `dark mode` - Dark mode toggle
- `toast notification` - Toast function
- `image preview` - Image preview
- `drag drop` - Drag and drop
- `clipboard copy` - Copy to clipboard
- `download` - Download file

## PHP

- `session start` - Start session
- `session destroy` - Destroy session
- `session get` - Get session value
- `session set` - Set session value
- `session flash` - Flash message
- `csrf token` - CSRF protection
- `password hash` - Hash password
- `password verify` - Verify password
- `autoload` - Class autoloader
- `namespace` - Namespace class
- `mail` - Send email
- `uuid` - Generate UUID
- `slug` - Create slug
- `date helper` - Date functions
- `error handler` - Error handling
- `logger` - Logging function
- `debug` - Debug function
- `dd` - Dump and die
- `dump` - Dump variable

## Authentication & Authorization

- `authcheck` - Check authentication
- `rolecheck` - Check role
- `readonlycheck` - Enforce read-only
- `sessionguard` - Guard session
- `ipcheck` - IP restriction
- `login` - Login form
- `register` - Registration form
- `logout` - Logout handler

## API & Response

- `apiresponse` - Response helpers
- `json response` - JSON output
- `success response` - Success response
- `error response` - Error response
- `apilogin` - Login API
- `apilogout` - Logout API
- `apiconfig` - Config API
- `apitasks` - Tasks API
- `apistatistics` - Statistics API
- `apireport` - Report API

## CRUD Operations

- `crudcreate` - Create record
- `crudread` - Read record
- `crudupdate` - Update record
- `cruddelete` - Delete record
- `crud store` - Store API
- `crud destroy` - Destroy API
- `crud index` - List records
- `crud edit` - Edit form

## Pages & Routes

- `pagelogin` - Login page
- `pagedashboard` - Dashboard router
- `pagecandidatedash` - Candidate dashboard
- `pagejudgedash` - Judge dashboard
- `pagemanagerdash` - Manager dashboard

## Security

- `xss` - XSS protection
- `sql injection` - SQL injection protection
- `rate limit` - Rate limiting
- `session timeout` - Session timeout
- `validate` - Input validation

## SQL

- `create database` - Create database
- `create table` - Create table
- `drop database` - Drop database
- `alter table` - Alter table
- `foreign key` - Foreign key
- `index` - Create index
- `unique` - Unique constraint
- `check` - Check constraint
- `having` - HAVING clause
- `procedure` - Stored procedure
- `seed` - Seed data
- `join` - Join tables
- `view` - Create view
- `trigger` - Create trigger

## Dashboard & UI

- `dashboard` - Dashboard layout
- `dashboard statistics` - Statistics cards
- `upload` - File upload
- `loading css` - Loading spinner

## WorldSkills Specific

- `project structure` - Project folder structure
- `mvc structure` - MVC folder structure
- `constants` - Application constants
- `installer` - Installation script

# Best Practices

Following these best practices will help you maintain a clean, efficient, and professional codebase.

## Organizing Snippets

### Group by Category

Organize your snippets logically by category to make them easier to find and remember. The WorldSkills snippets collection is already organized into categories:

- Database & PDO
- HTML & Bootstrap
- CSS
- JavaScript
- PHP
- Authentication
- API
- CRUD
- SQL
- Security
- Dashboard
- WorldSkills

### Use Descriptive Names

Give each snippet a clear, descriptive name that explains what it does. Good names include:

- ✅ "PDO SELECT query with prepared statement"
- ✅ "Login API with password verification"
- ❌ "Snippet 1"
- ❌ "Database thing"

### Consistent Naming Convention

Use a consistent naming convention across all snippets:

- Use lowercase for prefixes: `dbxampp`, `apilogin`, `pagelogin`
- Use descriptive prefixes: `fetchget` instead of `fg`
- Group related snippets: `apilogin`, `apilogout`, `apiconfig`

## Avoiding Duplicate Prefixes

Duplicate prefixes cause conflicts where VS Code cannot determine which snippet to expand. Follow these rules:

### Check for Conflicts

Before adding a new snippet, search the existing snippets file to ensure the prefix is unique:

```json
// Good - unique prefixes
"prefix": "fetchget"
"prefix": "fetchpost"
"prefix": "fetchput"

// Bad - duplicate prefix
"prefix": "fetch"
"prefix": "fetch"  // Conflict!
```

### Use Specific Prefixes

Make prefixes more specific to avoid conflicts:

```json
// Conflicting
"prefix": "card"  // Could be HTML card or CSS card

// Specific and clear
"prefix": "card html"   // HTML card component
"prefix": "card css"    // CSS card styling
```

### Scope-Based Differentiation

Use the scope property to limit where snippets appear:

```json
// Same prefix, different scopes
{
  "prefix": "table",
  "scope": "html",
  "body": ["<table>...</table>"]
},
{
  "prefix": "table",
  "scope": "sql",
  "body": ["CREATE TABLE..."]
}
```

## Using Placeholders Effectively

Placeholders make snippets flexible and guide users through customization.

### Number Tab Stops Sequentially

Always number tab stops starting from 1:

```json
{
  "body": [
    "${1:username}",
    "${2:email}",
    "${3:password}",
    "$0"  // Final cursor position
  ]
}
```

### Provide Helpful Defaults

Use meaningful default values in placeholders:

```json
// Good defaults
"${1:localhost}",
"${2:3306}",
"${3:database_name}"

// Less helpful defaults
"${1:value1}",
"${2:value2}",
"${3:value3}"
```

### Use Logical Tab Order

Arrange tab stops in the order users naturally fill them:

```json
{
  "body": [
    "const ${1:element} = document.querySelector('${2:.selector}');",
    "${1:element}.addEventListener('${3:click}', function() {",
    "  $0",
    "});"
  ]
}
```

## Keeping Snippets Maintainable

### Keep Snippets Focused

Each snippet should do one thing well:

```json
// Good - focused single purpose
"Login API with password verification"

// Bad - does too many things
"Login, register, password reset, and email verification"
```

### Limit Snippet Length

Keep snippets between 10-40 lines for optimal usability:

- **Too short (1-3 lines)**: Not worth creating a snippet
- **Ideal (10-40 lines)**: Good balance of utility and maintainability
- **Too long (50+ lines)**: Consider breaking into smaller snippets

### Document Complex Snippets

Add clear descriptions for complex snippets:

```json
{
  "description": "Dynamic WHERE clause builder that accepts an associative array of conditions and builds a prepared statement with proper parameter binding"
}
```

### Regular Maintenance

Periodically review and update your snippets:

- Remove unused snippets
- Update outdated patterns
- Add new frequently-used patterns
- Fix bugs or improve existing snippets

### Version Control

Keep your snippets file under version control:

```bash
git add worldskills.code-snippets
git commit -m "Add new API response snippets"
```

This allows you to:
- Track changes over time
- Revert to previous versions if needed
- Share snippets with team members
- Backup your customizations

## Security Best Practices

### Never Hardcode Credentials

Always use placeholders for sensitive data:

```json
// Bad - hardcoded credentials
"password": "mysecretpassword"

// Good - placeholder
"password": "${1:your_password_here}"
```

### Include Security Measures

Security-related snippets should include proper protections:

```json
{
  "body": [
    "// Always use prepared statements",
    "$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');",
    "$stmt->execute([$_GET['id']]);"
  ]
}
```

### Follow OWASP Guidelines

Ensure snippets follow security best practices:
- Input validation
- Output encoding
- Authentication
- Authorization
- CSRF protection
- SQL injection prevention
- XSS prevention

# Troubleshooting

This section helps you resolve common issues when working with VS Code snippets.

## Snippet Not Appearing

### Problem

You type a snippet prefix, but nothing appears in IntelliSense.

### Solutions

1. **Check Language Mode**
   - Ensure you're in the correct file type for the snippet
   - PHP snippets only work in `.php` files
   - HTML snippets only work in `.html` files
   - Check the bottom-right corner of VS Code for the language mode

2. **Reload VS Code**
   - Press `Ctrl + Shift + P`
   - Type "Developer: Reload Window"
   - Press Enter

3. **Check Prefix Spelling**
   - Verify you typed the prefix correctly
   - Prefixes are case-sensitive
   - Check for extra spaces or typos

4. **Verify Snippet File**
   - Open `worldskills.code-snippets`
   - Ensure JSON is valid (no syntax errors)
   - Check that the snippet exists in the file

5. **Trigger IntelliSense Manually**
   - Press `Ctrl + Space` to open IntelliSense
   - Type the prefix
   - Select the snippet from the list

## JSON Error

### Problem

VS Code shows a JSON syntax error in the snippets file.

### Solutions

1. **Check for Missing Commas**
   ```json
   // Missing comma after "body"
   {
     "prefix": "test",
     "body": ["code"]
     "description": "test"  // Missing comma here
   }
   ```

2. **Check for Trailing Commas**
   ```json
   // Trailing comma (invalid in JSON)
   {
     "prefix": "test",
     "body": ["code"],
     "description": "test",  // Remove this comma
   }
   ```

3. **Check for Unescaped Characters**
   ```json
   // Unescaped backslash in PHP
   "body": ["$variable = $value;"]  // Should be "\\$variable"
   ```

4. **Use JSON Validator**
   - Copy the file content
   - Paste into an online JSON validator
   - Fix any reported errors

5. **Check Quote Matching**
   ```json
   // Mismatched quotes
   "prefix": 'test',  // Should use double quotes
   ```

## Wrong Scope

### Problem

Snippet appears in wrong file types or not in the correct one.

### Solutions

1. **Check Scope Definition**
   ```json
   // Correct scope for PHP
   {
     "prefix": "test",
     "scope": "php",
     "body": ["<?php code ?>"]
   }
   ```

2. **Remove Scope for Global Snippets**
   ```json
   // Works in all file types
   {
     "prefix": "test",
     // No scope property
     "body": ["code"]
   }
   ```

3. **Use Multiple Scopes**
   ```json
   // Works in PHP and HTML
   {
     "prefix": "test",
     "scope": "php,html",
     "body": ["code"]
   }
   ```

## Reload Window Required

### Problem

Snippet changes don't take effect until VS Code is reloaded.

### Solutions

1. **Manual Reload**
   - Press `Ctrl + Shift + P`
   - Type "Developer: Reload Window"
   - Press Enter

2. **Auto-Reload Setting**
   - Open Settings (`Ctrl + ,`)
   - Search for "Auto Reload"
   - Enable "Window: Auto Reload"

3. **Close and Reopen**
   - Close the snippets file
   - Reopen the snippets file
   - Changes should now be active

## Wrong Language Mode

### Problem

File is opened in wrong language mode, so snippets don't appear.

### Solutions

1. **Check Language Mode**
   - Look at bottom-right corner of VS Code
   - Click the language indicator
   - Select correct language (PHP, HTML, CSS, etc.)

2. **Force Language Mode**
   - Press `Ctrl + K`, then `M`
   - Type language name
   - Select correct language

3. **Add Language Comment**
   ```php
   <?php
   // This forces PHP mode
   ```

   ```html
   <!-- This forces HTML mode -->
   <!DOCTYPE html>
   ```

## Duplicate Snippets

### Problem

Multiple snippets with same prefix cause conflicts.

### Solutions

1. **Find Duplicate Prefixes**
   - Open snippets file
   - Search for `"prefix":`
   - Look for duplicate values

2. **Rename Conflicting Snippets**
   ```json
   // Before (conflict)
   "prefix": "card"
   
   // After (resolved)
   "prefix": "card html"
   "prefix": "card css"
   ```

3. **Use Scope to Differentiate**
   ```json
   // Same prefix, different scopes
   {
     "prefix": "table",
     "scope": "html"
   },
   {
     "prefix": "table",
     "scope": "sql"
   }
   ```

4. **Remove Unused Duplicates**
   - Delete snippets you don't use
   - Keep only the most useful version

## IntelliSense Not Working

### Problem

IntelliSense suggestions don't appear at all.

### Solutions

1. **Check IntelliSense Settings**
   - Open Settings (`Ctrl + ,`)
   - Search for "IntelliSense"
   - Ensure it's enabled

2. **Check File Association**
   - Open Settings
   - Search for "Files: Associations"
   - Ensure `.php` maps to PHP, etc.

3. **Disable Conflicting Extensions**
   - Some extensions may interfere with IntelliSense
   - Disable extensions one by one to test

4. **Reset VS Code Settings**
   - Open Command Palette (`Ctrl + Shift + P`)
   - Type "Preferences: Open Settings (JSON)"
   - Look for IntelliSense settings
   - Reset to defaults if needed

## Snippet Expands Incorrectly

### Problem

Snippet expands but with wrong formatting or missing parts.

### Solutions

1. **Check Tab Stop Numbers**
   ```json
   // Wrong - skips number 2
   "${1:placeholder}",
   "${3:placeholder}"
   
   // Correct - sequential
   "${1:placeholder}",
   "${2:placeholder}",
   "${3:placeholder}"
   ```

2. **Check Escape Sequences**
   ```json
   // Wrong - unescaped backslash
   "$variable = $value;"
   
   // Correct - escaped backslash
   "\\$variable = \\$value;"
   ```

3. **Check Line Endings**
   - Ensure consistent line endings (LF or CRLF)
   - VS Code may show line ending in bottom-right corner
   - Click to change if needed

## Performance Issues

### Problem

VS Code becomes slow when typing snippet prefixes.

### Solutions

1. **Reduce Snippet Count**
   - Remove unused snippets
   - Keep only frequently used ones

2. **Organize by Scope**
   - Use specific scopes to limit snippet suggestions
   - Reduces IntelliSense load

3. **Disable Heavy Extensions**
   - Some extensions slow down IntelliSense
   - Disable unnecessary extensions

4. **Increase VS Code Memory**
   - Add to VS Code settings:
   ```json
   {
     "terminal.integrated.enablePersistentSessions": false
   }
   ```

# Keyboard Shortcuts

Mastering these keyboard shortcuts will significantly improve your productivity in VS Code.

## Command Palette

**Ctrl + Shift + P**

Opens the Command Palette, which gives you access to all VS Code commands. This is one of the most important shortcuts to memorize.

**Uses:**
- Open snippets configuration
- Reload window
- Change language mode
- Access all VS Code features

## IntelliSense

**Ctrl + Space**

Triggers IntelliSense suggestions, including snippets, code completion, and parameter hints.

**Uses:**
- See available snippets
- Get code completion suggestions
- View function parameters
- Explore available methods

**Tip:** If IntelliSense doesn't appear automatically, press this shortcut to trigger it manually.

## Tab Navigation

**Tab**

Moves to the next tab stop when editing a snippet. Also indents selected text.

**Uses:**
- Navigate between snippet placeholders
- Indent code blocks
- Accept IntelliSense suggestions

**Shift + Tab**

Moves to the previous tab stop. Also unindents selected text.

**Uses:**
- Go back to previous placeholder
- Unindent code blocks
- Navigate snippet in reverse

## Save Operations

**Ctrl + S**

Saves the current file.

**Uses:**
- Save your work frequently
- Commit changes to disk
- Trigger auto-formatting if configured

**Tip:** Enable Auto Save in settings to save automatically: `File > Auto Save`

## Selection Operations

**Ctrl + A**

Selects all content in the current file.

**Uses:**
- Select entire file content
- Replace all content quickly
- Copy entire file

**Tip:** Useful when replacing entire snippets file content.

**Ctrl + F**

Opens the Find dialog to search within the current file.

**Uses:**
- Find specific text
- Navigate to code sections
- Locate snippet prefixes

**Tip:** Use `Ctrl + Shift + F` to search across all files in the project.

**Ctrl + H**

Opens the Find and Replace dialog.

**Uses:**
- Replace text in current file
- Batch rename variables
- Update multiple occurrences

**Tip:** Use `Alt + Enter` to replace all occurrences at once.

## File Operations

**Ctrl + N**

Creates a new file.

**Uses:**
- Create new PHP, HTML, CSS files
- Start new components
- Add new pages

**Ctrl + O**

Opens an existing file.

**Uses:**
- Open files from project
- Navigate to specific files
- Access project structure

**Ctrl + W**

Closes the current file tab.

**Uses:**
- Close files you're done with
- Clean up workspace
- Manage open tabs

**Ctrl + Tab**

Switches between open file tabs.

**Uses:**
- Navigate between open files
- Switch context quickly
- Access recent files

## Editor Operations

**Ctrl + Z**

Undo the last action.

**Uses:**
- Revert mistakes
- Try different approaches
- Step back through changes

**Ctrl + Shift + Z** or **Ctrl + Y**

Redo the last undone action.

**Uses:**
- Restore undone changes
- Reapply reverted actions
- Move forward in history

**Ctrl + X**

Cuts selected text to clipboard.

**Uses:**
- Move code to different location
- Remove and paste elsewhere
- Reorganize code structure

**Ctrl + C**

Copies selected text to clipboard.

**Uses:**
- Duplicate code
- Copy snippets to other files
- Share code with team

**Ctrl + V**

Pastes clipboard content at cursor position.

**Uses:**
- Insert copied code
- Paste snippets
- Restore cut content

**Ctrl + D**

Selects the word at cursor and adds next occurrence to selection.

**Uses:**
- Edit multiple occurrences simultaneously
- Rename variables in scope
- Batch edit similar code

**Alt + Up/Down**

Moves the current line up or down.

**Uses:**
- Reorder code lines
- Organize code structure
- Move statements without cutting

**Alt + Shift + Up/Down**

Copies the current line up or down.

**Uses:**
- Duplicate lines
- Create similar code blocks
- Copy statements

**Ctrl + /**

Toggles line comment for current line or selection.

**Uses:**
- Comment out code temporarily
- Add documentation
- Disable code blocks

**Ctrl + Shift + K**

Deletes the current line.

**Uses:**
- Remove unwanted lines
- Clean up code
- Delete empty lines

## Window Management

**Ctrl + `**

Opens/closes the integrated terminal.

**Uses:**
- Run PHP scripts
- Execute git commands
- Run build tools

**Ctrl + B**

Toggles the side bar visibility.

**Uses:**
- Show/hide file explorer
- Access project structure
- Manage workspace

**Ctrl + Shift + E**

Focuses on the file explorer.

**Uses:**
- Navigate project files
- Access file tree
- Manage project structure

**Ctrl + Shift + F**

Opens search across all files.

**Uses:**
- Find code in entire project
- Locate function definitions
- Search for specific patterns

**Ctrl + P**

Quick open files by name.

**Uses:**
- Navigate to files quickly
- Open files without using explorer
- Access files by fuzzy search

**Tip:** Type `@` to search for symbols, `:` to go to line number.

## Multi-Cursor Editing

**Alt + Click**

Adds a cursor at clicked position.

**Uses:**
- Edit multiple locations simultaneously
- Change multiple variables
- Insert code in multiple places

**Ctrl + Alt + Up/Down**

Adds cursors above/below current line.

**Uses:**
- Edit multiple lines
- Create similar code patterns
- Batch edit vertical code

**Ctrl + L**

Selects the current line.

**Uses:**
- Select entire line quickly
- Copy or move lines
- Delete entire lines

**Ctrl + Shift + L**

Selects all occurrences of current selection.

**Uses:**
- Edit all matching text
- Rename all occurrences
- Batch replace patterns

# VS Code Tips

These tips will help you get the most out of Visual Studio Code for web development.

## IntelliSense

IntelliSense is VS Code's code completion and suggestion system. It provides:

- **Code Completion** - Suggests variables, functions, and classes as you type
- **Parameter Info** - Shows function parameters and types
- **Quick Info** - Displays type information on hover
- **Snippet Suggestions** - Shows available code snippets

### Enabling IntelliSense

IntelliSense is enabled by default. If it's not working:

1. Open Settings (`Ctrl + ,`)
2. Search for "IntelliSense"
3. Ensure "Editor: Quick Suggestions" is enabled
4. Check language-specific settings (PHP, HTML, CSS)

### Customizing IntelliSense

Adjust IntelliSense behavior in settings:

```json
{
  "editor.quickSuggestions": {
    "other": true,
    "comments": false,
    "strings": true
  },
  "editor.suggestSelection": "first",
  "editor.wordBasedSuggestions": true
}
```

## Emmet

Emmet is a powerful abbreviation engine for HTML and CSS. It allows you to write abbreviated code that expands into full HTML/CSS structures.

### Basic Emmet Examples

```html
<!-- Type this -->
div.container>ul>li*3

<!-- Expands to -->
<div class="container">
  <ul>
    <li></li>
    <li></li>
    <li></li>
  </ul>
</div>
```

```html
<!-- Type this -->
nav>ul>li*3>a[href="#"]

<!-- Expands to -->
<nav>
  <ul>
    <li><a href="#"></a></li>
    <li><a href="#"></a></li>
    <li><a href="#"></a></li>
  </ul>
</nav>
```

### Emmet for CSS

```css
/* Type this */
m10+p20

/* Expands to */
margin: 10px;
padding: 20px;
```

```css
/* Type this */
d:flex

/* Expands to */
display: flex;
```

### Enabling Emmet

Emmet is enabled by default for HTML and CSS. To enable for PHP:

1. Open Settings (`Ctrl + ,`)
2. Search for "Emmet"
3. Add "php" to "Emmet: Include Languages"

## Auto Save

Auto Save automatically saves your files as you work, preventing data loss.

### Enabling Auto Save

1. Click "File" in the menu bar
2. Click "Auto Save"
3. Or add to settings:
```json
{
  "files.autoSave": "afterDelay",
  "files.autoSaveDelay": 1000
}
```

### Auto Save Options

- **off** - No auto save (manual only)
- **afterDelay** - Save after configured delay (default 1000ms)
- **onFocusChange** - Save when editor loses focus
- **onWindowChange** - Save when window loses focus

## Format Document

Formatting your code makes it readable and maintainable.

### Manual Formatting

**Windows/Linux:** `Shift + Alt + F`
**Mac:** `Shift + Option + F`

### Auto Format on Save

Enable automatic formatting when saving:

```json
{
  "editor.formatOnSave": true,
  "editor.formatOnPaste": true,
  "editor.formatOnType": true
}
```

### Choosing a Formatter

Install a formatter extension (Prettier recommended) and configure:

```json
{
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "[php]": {
    "editor.defaultFormatter": "bmewburn.vscode-intelephense-client"
  }
}
```

## Extensions

Extensions add functionality to VS Code. Here are essential categories:

### How to Install Extensions

1. Click Extensions icon in sidebar (or `Ctrl + Shift + X`)
2. Search for extension name
3. Click "Install"
4. Reload VS Code if prompted

### Managing Extensions

- **Disable** - Turn off without uninstalling
- **Enable** - Turn back on
- **Uninstall** - Remove completely
- **Update** - Keep extensions current

### Extension Settings

Each extension has its own settings:

1. Open Extensions view
2. Click gear icon on extension
3. Select "Extension Settings"
4. Configure as needed

### Recommended Extension Workflow

1. Install core extensions first
2. Configure each extension
3. Test functionality
4. Add project-specific extensions
5. Document custom configurations

## Workspace Settings

VS Code supports workspace-specific settings, allowing different configurations for different projects.

### Creating Workspace Settings

1. Open project folder
2. Create `.vscode` folder
3. Create `settings.json` file
4. Add workspace-specific settings

### Example Workspace Settings

```json
{
  "php.validate.executablePath": "/usr/bin/php",
  "files.associations": {
    "*.php": "php"
  },
  "editor.tabSize": 4,
  "editor.insertSpaces": true
}
```

### User vs Workspace Settings

- **User Settings** - Apply globally to all projects
- **Workspace Settings** - Apply only to current project
- Workspace settings override user settings

## Multi-Root Workspaces

Multi-root workspaces allow you to work with multiple project folders simultaneously.

### Adding Folders to Workspace

1. File > Add Folder to Workspace
2. Select folder
3. Repeat for additional folders

### Benefits

- Work on frontend and backend together
- Reference shared libraries
- Manage related projects
- Switch contexts easily

## Git Integration

VS Code has built-in Git support for version control.

### Initializing Git

1. Open integrated terminal (`Ctrl + ``)
2. Run: `git init`
3. Run: `git add .`
4. Run: `git commit -m "Initial commit"`

### Git Commands in VS Code

- **Source Control** view (`Ctrl + Shift + G`)
- **Stage Changes** - Click + icon
- **Commit** - Type message and checkmark
- **Push/Pull** - Status bar icons
- **Branch** - Create and switch branches

### Git Configuration

Configure Git in settings:

```json
{
  "git.enableSmartCommit": true,
  "git.autofetch": true,
  "git.confirmSync": false
}
```

## Debugging

VS Code includes a powerful debugger for PHP and JavaScript.

### Setting Up PHP Debugging

1. Install Xdebug on your PHP server
2. Install "PHP Debug" extension
3. Configure `launch.json`:
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Listen for Xdebug",
      "type": "php",
      "request": "launch",
      "port": 9003
    }
  ]
}
```

### Debugging JavaScript

1. Install "Debugger for Chrome" extension
2. Configure `launch.json`:
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "chrome",
      "request": "launch",
      "name": "Launch Chrome",
      "url": "http://localhost:8080",
      "webRoot": "${workspaceFolder}"
    }
  ]
}
```

### Debugging Features

- **Breakpoints** - Click line number to set
- **Step Over** - `F10` - Execute current line
- **Step Into** - `F11` - Enter function
- **Step Out** - `Shift + F11` - Exit function
- **Continue** - `F5` - Resume execution
- **Watch** - Monitor variable values
- **Call Stack** - View execution path

## Tasks

Tasks automate build processes and development workflows.

### Creating Tasks

1. Create `.vscode/tasks.json`
2. Define task configuration:
```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "Run PHP Server",
      "type": "shell",
      "command": "php",
      "args": ["-S", "localhost:8000", "-t", "."],
      "group": "build",
      "isBackground": true
    }
  ]
}
```

### Running Tasks

1. `Ctrl + Shift + P`
2. Type "Tasks: Run Task"
3. Select task from list

### Default Build Task

Set a default task that runs with `Ctrl + Shift + B`:

```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "Build",
      "group": {
        "kind": "build",
        "isDefault": true
      },
      // ... task configuration
    }
  ]
}
```

# Recommended Extensions

These extensions enhance VS Code for web development and WorldSkills competition preparation.

## PHP Intelephense

**Publisher:** Ben Mewburn  
**Category:** PHP

The essential PHP extension for VS Code. Provides advanced IntelliSense, code navigation, and refactoring tools.

### Features

- Advanced autocomplete for PHP
- Code navigation (Go to Definition)
- Function parameter hints
- Code formatting
- Refactoring tools
- Docstring generation
- Signature help

### Why It's Essential

Intelephense provides the best PHP IntelliSense experience, significantly improving development speed and accuracy. It understands your code structure and provides intelligent suggestions.

### Configuration

```json
{
  "intelephense.files.maxSize": 5000000,
  "intelephense.completion.insertUseDeclaration": true,
  "intelephense.completion.fullyQualifyGlobalConstantsAndFunctions": true
}
```

## HTML CSS Support

**Publisher:** ECSS  
**Category:** HTML/CSS

Enhances HTML and CSS editing with intelligent code completion.

### Features

- HTML tag completion
- CSS class and ID completion
- HTML attribute suggestions
- CSS value completion
- Color preview
- Link to external files

### Why It's Essential

Provides context-aware suggestions for HTML and CSS, making it easier to write clean, valid markup and styles.

### Configuration

```json
{
  "html-css-class-completion.enableEmmetSupport": true,
  "html-css-class-completion.includeGlobPattern": "**/*.{css,html}"
}
```

## Bootstrap IntelliSense

**Publisher:** Matt Bierner  
**Category:** Bootstrap

Provides IntelliSense for Bootstrap classes and components.

### Features

- Bootstrap 5 class completion
- Component snippets
- Attribute suggestions
- Version-specific support

### Why It's Essential

If you're using Bootstrap (which many WorldSkills projects do), this extension eliminates the need to memorize class names and ensures correct usage.

### Configuration

```json
{
  "bootstrap5.intellisense.active": true,
  "bootstrap5.intellisense.framework": "bootstrap5"
}
```

## JavaScript Booster

**Publisher:** Werner Schmid  
**Category:** JavaScript

Boosts JavaScript and TypeScript development with smart code transformations.

### Features

- Code transformations (convert to const/let, arrow functions)
- JSX/TSX support
- Import/export organization
- Code navigation
- Refactoring tools

### Why It's Essential

Automates common JavaScript refactoring tasks, saving time and reducing errors in client-side code.

### Configuration

```json
{
  "javascript-booster.transformations": [
    "convertToArrowFunction",
    "convertToTemplateString",
    "convertToLetConst"
  ]
}
```

## Prettier

**Publisher:** Prettier  
**Category:** Formatter

An opinionated code formatter that enforces consistent style.

### Features

- Automatic code formatting
- Consistent style across team
- Support for multiple languages
- Configurable rules
- Format on save

### Why It's Essential

Ensures consistent code formatting across your project, making code more readable and maintainable. Essential for team collaboration.

### Configuration

Create `.prettierrc` file:
```json
{
  "semi": true,
  "singleQuote": true,
  "tabWidth": 4,
  "trailingComma": "es5",
  "printWidth": 80
}
```

VS Code settings:
```json
{
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.formatOnSave": true
}
```

## ESLint

**Publisher:** Microsoft  
**Category:** Linter

Identifies and reports on patterns in JavaScript to improve code quality.

### Features

- Real-time error detection
- Code quality checks
- Best practices enforcement
- Customizable rules
- Auto-fix capabilities

### Why It's Essential

Catches JavaScript errors and anti-patterns before runtime, improving code quality and reducing bugs.

### Configuration

Create `.eslintrc.json` file:
```json
{
  "env": {
    "browser": true,
    "es2021": true
  },
  "extends": "eslint:recommended",
  "parserOptions": {
    "ecmaVersion": 12,
    "sourceType": "module"
  },
  "rules": {
    "no-unused-vars": "warn",
    "no-console": "off"
  }
}
```

## GitLens

**Publisher:** GitKraken  
**Category:** Git

Supercharges Git capabilities within VS Code.

### Features

- Git blame annotations
- Code lens for recent changes
- File history view
- Commit search
- Branch comparison
- Merge visualization

### Why It's Essential

Provides deep Git integration, making version control operations visual and intuitive. Essential for tracking changes and understanding code history.

### Configuration

```json
{
  "gitlens.codeLens.enabled": true,
  "gitlens.currentLine.enabled": true,
  "gitlens.showWelcomeOnInstall": false
}
```

## Error Lens

**Publisher:** Alexander  
**Category:** Debugging

Improves error display by showing diagnostics inline with code.

### Features

- Inline error messages
- Warning highlights
- Quick fix suggestions
- Severity indicators
- Customizable display

### Why It's Essential

Makes errors and warnings immediately visible in the code, reducing the time spent debugging and fixing issues.

### Configuration

```json
{
  "errorLens.enabled": true,
  "errorLens.errorColor": "#ff0000",
  "errorLens.warningColor": "#ffa500",
  "errorLens.infoColor": "#0000ff"
}
```

## Path IntelliSense

**Publisher:** Christian Kohler  
**Category:** Productivity

Autocompletes filenames in your code.

### Features

- Filename autocompletion
- Path suggestions
- Import statement completion
- Relative path calculation
- Custom mapping

### Why It's Essential

Eliminates the need to remember file paths and reduces errors in include/require statements and imports.

### Configuration

```json
{
  "path-intellisense.mappings": {
    "@": "${workspaceRoot}/src"
  },
  "path-intellisense.extensionOnImport": true
}
```

## Auto Rename Tag

**Publisher:** Jun Han  
**Category:** HTML/XML

Automatically renames paired HTML/XML tags.

### Features

- Synchronized tag renaming
- Works with HTML, XML, JSX
- Instant updates
- No configuration needed

### Why It's Essential

Saves time when editing HTML by automatically updating closing tags when you rename opening tags. Prevents mismatched tag errors.

### Configuration

```json
{
  "auto-rename-tag.activationOnLanguage": [
    "html",
    "xml",
    "php",
    "javascript"
  ]
}
```

## Auto Close Tag

**Publisher:** Jun Han  
**Category:** HTML/XML

Automatically adds closing tags for HTML/XML.

### Features

- Automatic closing tag insertion
- Supports HTML, XML, JSX
- Configurable behavior
- Slash to close tag

### Why It's Essential

Speeds up HTML writing by automatically inserting closing tags, reducing typing and preventing unclosed tag errors.

### Configuration

```json
{
  "auto-close-tag.activationOnLanguage": [
    "html",
    "xml",
    "php",
    "javascript"
  ],
  "auto-close-tag.SublimeText3Mode": true
}
```

## Additional Recommended Extensions

### Live Server

**Publisher:** Ritwick Dey  
**Category:** Server

Launches a local development server with live reload.

- Instant page reload on save
- Static file serving
- Custom port configuration
- HTTPS support

### PHP Server

**Publisher:** bradcfry  
**Category:** Server

Launches PHP built-in server from VS Code.

- One-click PHP server
- Custom document root
- Port configuration
- Browser launch

### Material Icon Theme

**Publisher:** Philipp Kief  
**Category:** Theme

Material Design icons for files and folders.

- Beautiful file icons
- Folder color customization
- File association
- Theme integration

### VS Code Icons

**Publisher:** Roberto Huertas  
**Category:** Theme

Professional file icons for VS Code.

- Comprehensive icon set
- Folder customization
- File type recognition
- Multiple styles

### Bracket Pair Colorizer

**Publisher:** CoenraadS  
**Category:** Visual

Colors matching brackets for better code readability.

- Color-coded brackets
- Customizable colors
- Multiple bracket types
- Rainbow mode

### Indent Rainbow

**Publisher:**oderwat  
**Category:** Visual

Colors indentation levels for better code structure visualization.

- Color-coded indentation
- Customizable colors
- Multiple languages
- Highlight active indent

# License

This WorldSkills Code Snippets collection is licensed under the MIT License.

## MIT License

Copyright (c) 2026 WorldSkills Web Technologies

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Usage Rights

Under this license, you are free to:

- **Use** - Use the snippets in personal and commercial projects
- **Modify** - Customize snippets for your needs
- **Distribute** - Share snippets with others
- **Sublicense** - Include snippets in other projects
- **Sell** - Include snippets in commercial products

## Attribution

While not required, attribution is appreciated:

```
Code snippets from WorldSkills Code Snippets Collection
https://github.com/worldskills/code-snippets
```

## Contribution

Contributions are welcome! Feel free to:

- Report bugs
- Suggest new snippets
- Improve existing snippets
- Fix documentation
- Share your custom snippets

## Support

For issues, questions, or suggestions:

- Open an issue on the project repository
- Check existing documentation
- Review snippet examples
- Consult VS Code documentation

---

**Happy Coding!**

These snippets are designed to help you build amazing web applications faster and more efficiently. Whether you're preparing for a WorldSkills competition or working on a professional project, these tools will accelerate your development workflow and help you write better code.

Remember: The best way to learn is by doing. Start using these snippets in your projects, customize them to fit your needs, and share your improvements with the community.

Good luck with your WorldSkills competition and happy coding!
