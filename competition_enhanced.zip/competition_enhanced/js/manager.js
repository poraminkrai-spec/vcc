'use strict';

/* ────────────────────────────────────────────────────────────
   DATA LOAD
──────────────────────────────────────────────────────────── */
async function loadData() {
  try {
    const data = await apiFetch('/submission');
    renderDashboard(data);
    renderScores(data);
    renderRankingTable(data, 'rankingTable');
  } catch (err) {
    console.error('loadData error:', err);
  }
}

/* ────────────────────────────────────────────────────────────
   DASHBOARD STATS
──────────────────────────────────────────────────────────── */
function renderDashboard(data) {
  const total = data.length;
  const pass  = data.filter(t => (t.total_score || 0) >= 70).length;
  const fail  = total - pass;

  animateCount('totalCandidates', total);
  animateCount('passCount', pass);
  animateCount('failCount', fail);
}

function animateCount(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  const start    = parseInt(el.textContent) || 0;
  const duration = 600;
  const startTs  = performance.now();

  function step(ts) {
    const progress = Math.min((ts - startTs) / duration, 1);
    const eased    = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + (target - start) * eased);
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ────────────────────────────────────────────────────────────
   SCORE PANEL (enhanced sliders with visual fill)
──────────────────────────────────────────────────────────── */
function renderScores(data) {
  const container = document.getElementById('scoreTable');
  if (!container) return;

  if (data.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <div class="empty-state-icon">📋</div>
        <div class="empty-state-title">ยังไม่มีการส่งงาน</div>
        <div class="empty-state-desc">Submissions จะปรากฏเมื่อทีมส่งโปรเจกต์</div>
      </div>`;
    return;
  }

  const criteria = [
    { key: 'frontend',    label: 'Frontend',    max: 25, icon: '🖥️' },
    { key: 'backend',     label: 'Backend',     max: 25, icon: '⚙️' },
    { key: 'ui',          label: 'UI / UX',     max: 25, icon: '🎨' },
    { key: 'performance', label: 'Performance', max: 25, icon: '⚡' },
  ];

  container.innerHTML = data.map((team, cardIdx) => {
    const total = team.total_score || 0;
    const totalPct = (total / 100) * 100;
    const isPass = total >= 70;

    const sliders = criteria.map(({ key, label, max, icon }) => {
      const val = team[`${key}_score`] || 0;
      const pct = (val / max) * 100;

      return `
        <div class="range-group">
          <div class="range-header">
            <span class="range-label">${icon} ${label}</span>
            <span class="range-value" id="${key}-value-${team.id}">${val}</span>
          </div>
          <div class="range-track-wrap">
            <div class="range-fill" id="${key}-fill-${team.id}" style="width:${pct}%"></div>
            <input
              type="range" min="0" max="${max}" value="${val}"
              id="${key}-${team.id}"
              aria-label="${label} score for Team ${team.id}"
              oninput="onSliderChange('${key}', ${team.id}, this.value, ${max})"
            >
          </div>
        </div>`;
    }).join('');

    return `
      <div class="score-card" style="animation-delay:${cardIdx * 0.06}s">
        <div class="score-card-header">
          <div>
            <div class="score-card-title">Team #${team.id}</div>
            <div class="score-card-url">${team.frontend_url || 'ยังไม่ได้ส่ง URL'}</div>
          </div>
          <div class="score-total-badge" id="total-badge-${team.id}">${total} pts</div>
        </div>
        <div class="score-card-body">
          ${sliders}
          <!-- Progress bar showing total -->
          <div style="margin-top:var(--s2)">
            <div style="display:flex;justify-content:space-between;font-size:var(--text-xs);color:var(--text-tertiary);margin-bottom:var(--s2)">
              <span>คะแนนรวม</span>
              <span style="color:${isPass?'var(--success)':'var(--warning)'}">
                ${isPass ? '✓ ผ่าน' : '✗ ต่ำกว่าเกณฑ์'}
              </span>
            </div>
            <div class="score-bar-bg" style="height:8px">
              <div class="score-bar-fill${isPass?'':' warn'}" id="total-bar-${team.id}" style="width:${totalPct}%"></div>
            </div>
          </div>
        </div>
        <div class="score-card-footer">
          <button class="btn-primary btn-sm" onclick="saveScore(${team.id})" id="save-btn-${team.id}">
            <svg width="11" height="11" viewBox="0 0 16 16" fill="none">
              <path d="M3 8l3 3 7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            บันทึกคะแนน
          </button>
        </div>
      </div>`;
  }).join('');
}

/* ────────────────────────────────────────────────────────────
   SLIDER LIVE UPDATE
──────────────────────────────────────────────────────────── */
function onSliderChange(key, teamId, value, max) {
  // Update display value
  const valEl = document.getElementById(`${key}-value-${teamId}`);
  if (valEl) valEl.textContent = value;

  // Update fill bar
  const fillEl = document.getElementById(`${key}-fill-${teamId}`);
  if (fillEl) fillEl.style.width = `${(value / max) * 100}%`;

  // Recalculate total live
  const criteria = ['frontend', 'backend', 'ui', 'performance'];
  let total = 0;
  for (const k of criteria) {
    const el = document.getElementById(`${k}-${teamId}`);
    if (el) total += parseInt(el.value) || 0;
  }

  const badge = document.getElementById(`total-badge-${teamId}`);
  if (badge) badge.textContent = `${total} pts`;

  const totalBar = document.getElementById(`total-bar-${teamId}`);
  if (totalBar) {
    totalBar.style.width = `${total}%`;
    if (total >= 70) totalBar.classList.remove('warn');
    else totalBar.classList.add('warn');
  }
}

/* ────────────────────────────────────────────────────────────
   SAVE SCORE
──────────────────────────────────────────────────────────── */
async function saveScore(id) {
  const fields = ['frontend', 'backend', 'ui', 'performance'];
  const payload = {};

  for (const f of fields) {
    const el = document.getElementById(`${f}-${id}`);
    if (!el) { showToast('ไม่พบช่องกรอกคะแนน', 'error'); return; }
    payload[`${f}_score`] = Number(el.value);
  }

  const btn = document.getElementById(`save-btn-${id}`);
  if (btn) { btn.setAttribute('data-loading', ''); btn.disabled = true; }

  try {
    const data = await apiFetch(`/submission/score/${id}`, {
      method: 'PUT',
      body:   JSON.stringify(payload),
    });

    if (data.success) {
      showToast(`บันทึกคะแนน Team #${id} เรียบร้อย ✓`, 'success');
      loadData();
    } else {
      showToast(data.message || 'ไม่สามารถบันทึกคะแนนได้', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Server error ไม่สามารถบันทึกคะแนนได้', 'error');
  } finally {
    if (btn) { btn.removeAttribute('data-loading'); btn.disabled = false; }
  }
}

/* ────────────────────────────────────────────────────────────
   SECTION SWITCH
──────────────────────────────────────────────────────────── */
function showSection(sectionId, navEl) {
  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  const target = document.getElementById(sectionId);
  if (target) target.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.remove('active');
    el.removeAttribute('aria-current');
  });
  if (navEl) { navEl.classList.add('active'); navEl.setAttribute('aria-current', 'page'); }
  const titleEl = document.getElementById('page-title');
  if (titleEl && navEl) titleEl.textContent = navEl.textContent.trim();
}

/* ────────────────────────────────────────────────────────────
   INIT
──────────────────────────────────────────────────────────── */
loadData();
setInterval(loadData, 5000);
