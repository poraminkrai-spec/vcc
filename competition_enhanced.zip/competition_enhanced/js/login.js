'use strict';

const API_BASE = 'http://localhost:3000/api';

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('input').forEach(input => {
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') login();
    });
  });
});

async function login() {
  const usernameEl = document.getElementById('username');
  const passwordEl = document.getElementById('password');
  const statusEl   = document.getElementById('status');
  const btn        = document.getElementById('login-btn');

  const username = usernameEl.value.trim();
  const password = passwordEl.value;

  statusEl.textContent = '';
  statusEl.classList.remove('visible');

  if (!username || !password) {
    showError('กรุณากรอก username และ password');
    return;
  }

  btn.setAttribute('data-loading', '');
  btn.disabled = true;
  btn.textContent = 'กำลังเข้าสู่ระบบ...';

  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ username, password }),
    });

    const data = await res.json();

    if (data.success) {
      btn.textContent = '✓ กำลังเปลี่ยนหน้า...';

      const routes = {
        candidate: 'pages/candidate.html',
        judge:     'pages/judge.html',
        manager:   'pages/manager.html',
      };

      const dest = routes[data.role];
      if (dest) {
        window.location.href = dest;
      } else {
        showError('Unknown role. กรุณาติดต่อผู้ดูแลระบบ');
        resetBtn();
      }
    } else {
      showError('Username หรือ password ไม่ถูกต้อง');
      passwordEl.value = '';
      passwordEl.focus();
      resetBtn();
    }

  } catch (err) {
    console.error('Login error:', err);
    showError('ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ กรุณาลองใหม่');
    resetBtn();
  }

  function showError(msg) {
    statusEl.textContent = msg;
    statusEl.classList.add('visible');
  }

  function resetBtn() {
    btn.removeAttribute('data-loading');
    btn.disabled = false;
    btn.textContent = 'เข้าสู่ระบบ';
  }
}
