'use strict';

/* ────────────────────────────────────────────────────────────
   STATE
──────────────────────────────────────────────────────────── */
const DEFAULT_DURATION = 3 * 60 * 60;
let timeLeft     = DEFAULT_DURATION;
let timerStarted = false;

/* ────────────────────────────────────────────────────────────
   CLOCK
──────────────────────────────────────────────────────────── */
setInterval(() => updateClock('clock'), 1000);
updateClock('clock');

/* ────────────────────────────────────────────────────────────
   TIMER TICK (circular rings)
──────────────────────────────────────────────────────────── */
function renderTimer() {
  const el = document.getElementById('timer');
  if (!el) return;

  const safe = Math.max(0, timeLeft);
  el.textContent = formatDuration(safe);

  el.className = 'clock-hms';
  if (timerStarted && safe > 0) {
    if (safe <= 600) el.classList.add('warning');
    else el.classList.add('running');
  } else if (safe <= 0 && timerStarted) {
    el.classList.add('expired');
  }

  updateRingTimer(DEFAULT_DURATION, safe);
}

renderTimer();

setInterval(() => {
  if (timerStarted && timeLeft > 0) {
    timeLeft--;
    renderTimer();
  }
}, 1000);

/* ────────────────────────────────────────────────────────────
   SESSION STATUS
──────────────────────────────────────────────────────────── */
async function loadSession() {
  try {
    const data = await apiFetch('/session/status');
    const isOpen = data.status === 'open';

    const dot        = document.getElementById('status-dot');
    const label      = document.getElementById('sessionStatus');
    const dashDot    = document.getElementById('dash-status-dot');
    const dashLabel  = document.getElementById('dashSessionStatus');

    if (dot)       dot.className     = `session-dot${isOpen ? ' live' : ''}`;
    if (label)     label.textContent  = isOpen ? 'Live' : 'Closed';
    if (dashDot)   dashDot.className  = `session-dot${isOpen ? ' live' : ''}`;
    if (dashLabel) dashLabel.textContent = isOpen ? 'Live' : 'Closed';

    if (isOpen) {
      if (!timerStarted) {
        if (data.end_time) {
          timeLeft = Math.max(0, Math.floor((new Date(data.end_time) - new Date()) / 1000));
        }
        timerStarted = true;
        renderTimer();
      }
    } else {
      timerStarted = false;
    }
  } catch (err) {
    console.error('loadSession error:', err);
  }
}

/* ────────────────────────────────────────────────────────────
   SUBMIT
──────────────────────────────────────────────────────────── */
async function submitProject() {
  const frontendUrl = document.getElementById('frontendUrl')?.value.trim();
  const backendUrl  = document.getElementById('backendUrl')?.value.trim();
  const btn         = document.getElementById('submit-btn');

  if (!frontendUrl || !backendUrl) {
    showToast('กรุณากรอก Frontend และ Backend URLs ให้ครบ', 'error');
    return;
  }

  if (!frontendUrl.startsWith('http') || !backendUrl.startsWith('http')) {
    showToast('URL ต้องเริ่มต้นด้วย http:// หรือ https://', 'error');
    return;
  }

  btn.setAttribute('data-loading', '');
  btn.disabled = true;

  try {
    const data = await apiFetch('/submission', {
      method: 'POST',
      body:   JSON.stringify({ frontend_url: frontendUrl, backend_url: backendUrl }),
    });

    if (data.success) {
      showToast('ส่งโปรเจกต์สำเร็จ! 🎉', 'success');
      document.getElementById('frontendUrl').value = '';
      document.getElementById('backendUrl').value  = '';
    } else {
      showToast(data.message || 'ส่งโปรเจกต์ไม่สำเร็จ', 'error');
    }
  } catch (err) {
    console.error('submitProject error:', err);
    showToast('Server error กรุณาลองใหม่อีกครั้ง', 'error');
  } finally {
    btn.removeAttribute('data-loading');
    btn.disabled = false;
  }
}

/* ────────────────────────────────────────────────────────────
   RANKING
──────────────────────────────────────────────────────────── */
async function loadRanking() {
  try {
    const data = await apiFetch('/submission');
    renderRankingTable(data, 'rankingTable');
  } catch (err) {
    console.error('loadRanking error:', err);
  }
}

/* ────────────────────────────────────────────────────────────
   SECTION SWITCH
──────────────────────────────────────────────────────────── */
function showSection(sectionId, navEl) {
  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  const target = document.getElementById(sectionId);
  if (target) target.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.remove('active');
    el.removeAttribute('aria-current');
  });
  if (navEl) { navEl.classList.add('active'); navEl.setAttribute('aria-current', 'page'); }
  const titleEl = document.getElementById('page-title');
  if (titleEl && navEl) titleEl.textContent = navEl.textContent.trim();
  if (sectionId === 'rankingSection') loadRanking();
}

/* ────────────────────────────────────────────────────────────
   INIT
──────────────────────────────────────────────────────────── */
loadSession();
loadRanking();

setInterval(() => {
  loadSession();
  loadRanking();
}, 5000);
