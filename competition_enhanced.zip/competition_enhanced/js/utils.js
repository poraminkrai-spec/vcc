/* ============================================================
   UTILS.JS — Shared Utilities · Competition Platform
   ============================================================ */

'use strict';

const API = 'http://localhost:3000/api';

/* ────────────────────────────────────────────────────────────
   TOAST
──────────────────────────────────────────────────────────── */
function showToast(message, type = 'info', duration = 3200) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.setAttribute('role', 'alert');

  const iconMap = {
    success: `<svg class="toast-icon" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="6" fill="rgba(16,245,160,.15)" stroke="var(--success)" stroke-width="1.3"/>
      <path d="M5 8l2 2 4-4" stroke="var(--success)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`,
    error: `<svg class="toast-icon" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="6" fill="rgba(255,77,106,.12)" stroke="var(--danger)" stroke-width="1.3"/>
      <path d="M5.5 5.5l5 5M10.5 5.5l-5 5" stroke="var(--danger)" stroke-width="1.5" stroke-linecap="round"/>
    </svg>`,
    info: `<svg class="toast-icon" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="6" fill="rgba(0,212,255,.08)" stroke="var(--accent)" stroke-width="1.3"/>
      <path d="M8 7v4M8 5.2v.8" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round"/>
    </svg>`,
  };

  toast.innerHTML = `${iconMap[type] || iconMap.info}<span>${message}</span>`;
  container.appendChild(toast);

  const remove = () => {
    toast.classList.add('exiting');
    toast.addEventListener('animationend', () => toast.remove(), { once: true });
  };

  const timer = setTimeout(remove, duration);
  toast.addEventListener('click', () => { clearTimeout(timer); remove(); });
}

/* ────────────────────────────────────────────────────────────
   FETCH HELPERS
──────────────────────────────────────────────────────────── */
async function apiFetch(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.message || `HTTP ${response.status}`);
  }
  return response.json();
}

/* ────────────────────────────────────────────────────────────
   CLOCK (current time sub-label)
──────────────────────────────────────────────────────────── */
function updateClock(elementId) {
  const el = document.getElementById(elementId);
  if (!el) return;
  const now = new Date();
  const date = now.toLocaleDateString('th-TH', { weekday: 'short', month: 'short', day: 'numeric' });
  const time = now.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  el.textContent = `${date} · ${time}`;
}

/* ────────────────────────────────────────────────────────────
   TIMER HELPERS
──────────────────────────────────────────────────────────── */
function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

/**
 * Update the circular ring SVG timer
 * @param {number} totalSeconds - total duration (e.g. 3*60*60)
 * @param {number} remaining - seconds remaining
 */
function updateRingTimer(totalSeconds, remaining) {
  const safe = Math.max(0, remaining);

  const totalH = totalSeconds;
  const totalM = 3600; // 1 hour for minute ring
  const totalS = 60;   // 60 seconds for second ring

  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = safe % 60;

  // Circumferences: r=65→408.41, r=55→345.58, r=45→282.74
  const CIRC_H = 408.41;
  const CIRC_M = 345.58;
  const CIRC_S = 282.74;

  const ringH = document.getElementById('ring-h');
  const ringM = document.getElementById('ring-m');
  const ringS = document.getElementById('ring-s');

  if (ringH) {
    const ratioH = totalH > 0 ? safe / totalH : 0;
    ringH.style.strokeDashoffset = CIRC_H * (1 - ratioH);
  }

  if (ringM) {
    const ratioM = m / 60;
    ringM.style.strokeDashoffset = CIRC_M * (1 - ratioM);
  }

  if (ringS) {
    const ratioS = s / 60;
    ringS.style.strokeDashoffset = CIRC_S * (1 - ratioS);
  }
}

/* ────────────────────────────────────────────────────────────
   RANKING RENDERER (enhanced with score bars)
──────────────────────────────────────────────────────────── */
function renderRankingTable(data, tbodyId) {
  const tbody = document.getElementById(tbodyId);
  if (!tbody) return;

  const sorted = [...data].sort((a, b) => (b.total_score || 0) - (a.total_score || 0));

  if (sorted.length === 0) {
    tbody.innerHTML = `<tr><td colspan="3"><div class="empty-state">
      <div class="empty-state-icon">🏅</div>
      <div class="empty-state-title">ยังไม่มีข้อมูลอันดับ</div>
    </div></td></tr>`;
    return;
  }

  const maxScore = sorted[0]?.total_score || 100;

  tbody.innerHTML = sorted.map((team, i) => {
    const medals = ['🥇','🥈','🥉'];
    const rank = i < 3
      ? `<span class="rank-medal">${medals[i]}</span>`
      : `<span class="rank-cell">#${i + 1}</span>`;

    const score = team.total_score || 0;
    const pct = maxScore > 0 ? (score / 100) * 100 : 0;
    const isWarn = score < 70;
    const scoreColor = score >= 70 ? 'var(--success)' : score > 0 ? 'var(--warning)' : 'var(--text-tertiary)';

    return `
      <tr>
        <td>${rank}</td>
        <td style="color:var(--text-primary);font-weight:600">Team ${team.id}</td>
        <td>
          <div class="score-bar-wrap">
            <div class="score-bar-bg">
              <div class="score-bar-fill${isWarn?' warn':''}" style="width:${pct}%"></div>
            </div>
            <div class="score-bar-num" style="color:${scoreColor}">${score}</div>
          </div>
        </td>
      </tr>`;
  }).join('');

  // Animate bars in
  requestAnimationFrame(() => {
    tbody.querySelectorAll('.score-bar-fill').forEach((bar, i) => {
      const target = bar.style.width;
      bar.style.width = '0';
      setTimeout(() => { bar.style.width = target; }, i * 60 + 100);
    });
  });
}

/* ────────────────────────────────────────────────────────────
   SECTION SWITCH (shared base — can be overridden per page)
──────────────────────────────────────────────────────────── */
function showSection(sectionId, navEl) {
  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  const target = document.getElementById(sectionId);
  if (target) target.classList.add('active');

  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.remove('active');
    el.removeAttribute('aria-current');
  });
  if (navEl) {
    navEl.classList.add('active');
    navEl.setAttribute('aria-current', 'page');
  }

  const titleEl = document.getElementById('page-title');
  if (titleEl && navEl) titleEl.textContent = navEl.textContent.trim();
}
