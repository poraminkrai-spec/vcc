async function login(){

    const username =
        document.getElementById("username").value;

    const password =
        document.getElementById("password").value;

    const status =
        document.getElementById("status");

    try{

        const res = await fetch(
            "http://localhost:3000/api/auth/login",
            {
                method:"POST",

                headers:{
                    "Content-Type":"application/json"
                },

                body:JSON.stringify({
                    username,
                    password
                })

            }
        );

        const data = await res.json();

        if(data.success){

            if(data.role === "candidate"){

                window.location.href =
                "pages/candidate.html";

            }

            else if(data.role === "judge"){

                window.location.href =
                "pages/judge.html";

            }

            else if(data.role === "manager"){

                window.location.href =
                "pages/manager.html";

            }

        }

        else{

            status.innerText =
            "Invalid Username Or Password";

        }

    }

    catch(err){

        status.innerText =
        "Server Connection Error";

        console.log(err);

    }

}