const DEFAULT_DURATION = 3 * 60 * 60;

let duration     = DEFAULT_DURATION;
let timerStarted = false;
let sessionState = "closed";

/* =========================
   LIVE CLOCK
========================= */

function updateClock() {

    const now  = new Date();
    const date = now.toLocaleDateString("en-US", {
        weekday: "short",
        year:    "numeric",
        month:   "short",
        day:     "numeric"
    });
    const time = now.toLocaleTimeString("en-GB", {
        hour:   "2-digit",
        minute: "2-digit",
        second: "2-digit"
    });

    document.getElementById("clock").innerHTML = `${date} • ${time}`;

}

setInterval(updateClock, 1000);
updateClock();

/* =========================
   COUNTDOWN
========================= */

function renderTimer() {

    const h = Math.floor(duration / 3600);
    const m = Math.floor((duration % 3600) / 60);
    const s = duration % 60;

    document.getElementById("timer").innerText =
        `${String(h).padStart(2,"0")}:` +
        `${String(m).padStart(2,"0")}:` +
        `${String(s).padStart(2,"0")}`;

}

renderTimer();

setInterval(() => {
    if (timerStarted && duration > 0) {
        duration--;
        renderTimer();
    }
}, 1000);

/* =========================
   SESSION STATUS
========================= */

async function loadStatus() {

    try {

        const res  = await fetch("http://localhost:3000/api/session/status");
        const data = await res.json();

        const statusText = document.getElementById("sessionStatus");

        if (data.status === "open") {

            statusText.innerText   = "LIVE";
            statusText.className   = "status-open";

            if (sessionState !== "open") {
                // Sync timer with server end_time
                if (data.end_time) {
                    duration = Math.max(
                        0,
                        Math.floor((new Date(data.end_time) - new Date()) / 1000)
                    );
                    renderTimer();
                }
            }

            timerStarted = true;
            sessionState = "open";

        } else {

            statusText.innerText = "CLOSED";
            statusText.className = "status-closed";

            timerStarted = false;
            duration     = DEFAULT_DURATION;
            renderTimer();
            sessionState = "closed";

        }

    } catch (err) {
        console.error("loadStatus error:", err);
    }

}

/* =========================
   OPEN / CLOSE SESSION
========================= */

async function openSession() {

    try {

        const res  = await fetch("http://localhost:3000/api/session/open", { method: "PUT" });
        const data = await res.json();

        if (data.success) {
            loadStatus();
        }

    } catch (err) {
        console.error(err);
    }

}

async function closeSession() {

    try {

        const res  = await fetch("http://localhost:3000/api/session/close", { method: "PUT" });
        const data = await res.json();

        if (data.success) {
            loadStatus();
        }

    } catch (err) {
        console.error(err);
    }

}

/* =========================
   LOAD SUBMISSIONS
========================= */

async function loadSubmissions() {

    try {

        const res   = await fetch("http://localhost:3000/api/submission");
        const data  = await res.json();
        const table = document.getElementById("submissionTable");

        table.innerHTML = "";

        data.forEach((item) => {

            // BUG FIX: dynamic status class instead of always "pending"
            const statusClass =
                item.status === "SUBMITTED" ? "pending" :
                item.status === "SCORED"    ? "scored"  :
                "pending";

            table.innerHTML += `
            <tr>
                <td>#${item.id}</td>
                <td>${item.frontend_url || "-"}</td>
                <td>
                    <span class="status ${statusClass}">
                        ${item.status}
                    </span>
                </td>
                <td>
                    <button onclick="recheck(${item.id})">Re-check</button>
                </td>
            </tr>`;

        });

    } catch (err) {
        console.error("loadSubmissions error:", err);
    }

}

/* =========================
   RECHECK
   BUG FIX: route now exists in backend
========================= */

async function recheck(id) {

    try {

        const res  = await fetch(
            `http://localhost:3000/api/submission/${id}/recheck`,
            { method: "POST" }
        );
        const data = await res.json();

        if (data.success) {
            loadSubmissions();
        }

    } catch (err) {
        console.error(err);
    }

}

/* =========================
   INITIALIZE
========================= */

loadStatus();
loadSubmissions();

setInterval(() => {
    loadStatus();
    loadSubmissions();
}, 3000);

/* =========================
   SECTION SWITCH (judge)
========================= */

function showSection(sectionId) {

    ["dashboardSection", "submissionSection", "rankingSection"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = "none";
    });

    document.getElementById(sectionId).style.display = "block";

    // Update active link
    document.querySelectorAll(".sidebar .menu a").forEach(a => a.classList.remove("active"));
    event.target.classList.add("active");

    if (sectionId === "rankingSection") {
        renderRankingFromData();
    }

}

let _lastSubmissionData = [];

async function renderRankingFromData() {

    try {

        const res  = await fetch("http://localhost:3000/api/submission");
        const data = await res.json();

        const ranking = [...data].sort(
            (a, b) => (b.total_score || 0) - (a.total_score || 0)
        );

        const table = document.getElementById("rankingTable");
        if (!table) return;

        table.innerHTML = "";

        ranking.forEach((team, index) => {
            const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `#${index + 1}`;
            table.innerHTML += `
            <tr>
                <td>${medal}</td>
                <td>Team ${team.id}</td>
                <td>${team.total_score || 0}</td>
            </tr>`;
        });

    } catch (err) {
        console.error(err);
    }

}
