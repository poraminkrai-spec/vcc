/* =========================
   SECTION SWITCH
========================= */

function showSection(sectionId) {

    ["dashboardSection", "scoreSection", "rankingSection"].forEach(id => {
        document.getElementById(id).style.display = "none";
    });

    document.getElementById(sectionId).style.display = "block";

}

/* =========================
   LOAD DATA
========================= */

async function loadData() {

    try {

        const res  = await fetch("http://localhost:3000/api/submission");
        const data = await res.json();

        renderDashboard(data);
        renderScores(data);
        renderRanking(data);

    } catch (err) {
        console.error("loadData error:", err);
    }

}

/* =========================
   DASHBOARD
========================= */

function renderDashboard(data) {

    document.getElementById("totalCandidates").innerText = data.length;

    const pass = data.filter(item => (item.total_score || 0) >= 70).length;
    const fail = data.filter(item => (item.total_score || 0) <  70).length;

    document.getElementById("passCount").innerText = pass;
    document.getElementById("failCount").innerText = fail;

}

/* =========================
   SCORE PANEL
========================= */

function renderScores(data) {

    const container = document.getElementById("scoreTable");
    container.innerHTML = "";

    data.forEach((team) => {

        const scores = [
            { key: "frontend",    label: "Frontend" },
            { key: "backend",     label: "Backend" },
            { key: "ui",          label: "UI / UX" },
            { key: "performance", label: "Performance" }
        ];

        const sliders = scores.map(({ key, label }) => `
            <div class="score-item">
                <div class="score-header">
                    <label for="${key}-${team.id}">${label}</label>
                    <span id="${key}-value-${team.id}">${team[key + "_score"] || 0}</span>
                </div>
                <input
                    type="range"
                    min="0" max="25"
                    value="${team[key + "_score"] || 0}"
                    id="${key}-${team.id}"
                    oninput="document.getElementById('${key}-value-${team.id}').innerText=this.value"
                >
            </div>
        `).join("");

        container.innerHTML += `
        <div class="score-card">
            <div class="score-top">
                <div>
                    <h2>Team #${team.id}</h2>
                    <p class="project-link">${team.frontend_url || "-"}</p>
                </div>
                <span class="rank-badge">${team.total_score || 0} pts</span>
            </div>
            ${sliders}
            <button onclick="saveScore(${team.id})">Save Score</button>
        </div>`;

    });

}

/* =========================
   SAVE SCORE
========================= */

async function saveScore(id) {

    const frontend_score    = document.getElementById(`frontend-${id}`).value;
    const backend_score     = document.getElementById(`backend-${id}`).value;
    const ui_score          = document.getElementById(`ui-${id}`).value;
    const performance_score = document.getElementById(`performance-${id}`).value;

    try {

        const res = await fetch(`http://localhost:3000/api/submission/score/${id}`, {
            method:  "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                frontend_score,
                backend_score,
                ui_score,
                performance_score
            })
        });

        const data = await res.json();

        if (data.success) {
            alert("Saved Successfully");
            loadData();
        } else {
            alert("Save failed: " + (data.message || "Unknown error"));
        }

    } catch (err) {
        console.error(err);
        alert("Server Connection Error");
    }

}

/* =========================
   RANKING
========================= */

function renderRanking(data) {

    const ranking = [...data].sort(
        (a, b) => (b.total_score || 0) - (a.total_score || 0)
    );

    const table = document.getElementById("rankingTable");
    table.innerHTML = "";

    ranking.forEach((team, index) => {

        const medal =
            index === 0 ? "🥇" :
            index === 1 ? "🥈" :
            index === 2 ? "🥉" :
            `#${index + 1}`;

        table.innerHTML += `
        <tr>
            <td>${medal}</td>
            <td>Team ${team.id}</td>
            <td>${team.total_score || 0}</td>
        </tr>`;

    });

}

/* =========================
   INIT — auto-refresh every 5 seconds
========================= */

loadData();

setInterval(loadData, 5000);
