/* =========================
   SECTION SWITCH
========================= */

function showSection(sectionId) {

    ["dashboardSection", "submitSection", "rankingSection"].forEach(id => {
        document.getElementById(id).style.display = "none";
    });

    document.getElementById(sectionId).style.display = "block";

    // Auto-load ranking when switching to ranking tab
    if (sectionId === "rankingSection") {
        loadRanking();
    }

}

/* =========================
   LOAD SESSION
========================= */

async function loadSession() {

    try {

        const res  = await fetch("http://localhost:3000/api/session/status");
        const data = await res.json();

        const statusEl = document.getElementById("sessionStatus");
        statusEl.innerText = data.status.toUpperCase();

        // BUG FIX: sync timer state with actual session status
        if (data.status === "open") {
            statusEl.className = "status-open";
            if (!timerStarted) {
                // Calculate remaining time from end_time
                if (data.end_time) {
                    const remaining = Math.max(
                        0,
                        Math.floor((new Date(data.end_time) - new Date()) / 1000)
                    );
                    timeLeft = remaining;
                }
                timerStarted = true;
            }
        } else {
            statusEl.className = "status-closed";
            timerStarted = false;
        }

    } catch (err) {
        console.error("loadSession error:", err);
    }

}

/* =========================
   CLOCK
========================= */

function updateClock() {

    const now = new Date();
    document.getElementById("clock").innerText = now.toLocaleString();

}

setInterval(updateClock, 1000);
updateClock();

/* =========================
   TIMER
   BUG FIX: timer syncs with server session, stops when closed
========================= */

let timeLeft     = 3 * 60 * 60;
let timerStarted = false;

function renderTimer() {

    const h = Math.floor(timeLeft / 3600);
    const m = Math.floor((timeLeft % 3600) / 60);
    const s = timeLeft % 60;

    document.getElementById("timer").innerText =
        `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;

}

renderTimer();

setInterval(() => {

    if (timerStarted && timeLeft > 0) {
        timeLeft--;
        renderTimer();
    }

}, 1000);

/* =========================
   SUBMIT PROJECT
   BUG FIX: validate inputs before submit
========================= */

async function submitProject() {

    const frontend_url = document.getElementById("frontendUrl").value.trim();
    const backend_url  = document.getElementById("backendUrl").value.trim();

    if (!frontend_url || !backend_url) {
        alert("Please fill in both Frontend URL and Backend URL");
        return;
    }

    try {

        const res = await fetch("http://localhost:3000/api/submission", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ frontend_url, backend_url })
        });

        const data = await res.json();

        if (data.success) {
            alert("Project Submitted Successfully!");
            document.getElementById("frontendUrl").value = "";
            document.getElementById("backendUrl").value  = "";
        } else {
            alert("Submit failed: " + (data.message || "Unknown error"));
        }

    } catch (err) {
        alert("Server Connection Error");
        console.error(err);
    }

}

/* =========================
   RANKING
   BUG FIX: add auto-refresh every 5 seconds
========================= */

async function loadRanking() {

    try {

        const res  = await fetch("http://localhost:3000/api/submission");
        const data = await res.json();

        const ranking = [...data].sort(
            (a, b) => (b.total_score || 0) - (a.total_score || 0)
        );

        const table = document.getElementById("rankingTable");
        table.innerHTML = "";

        ranking.forEach((team, index) => {

            const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `#${index + 1}`;

            table.innerHTML += `
            <tr>
                <td>${medal}</td>
                <td>Team ${team.id}</td>
                <td>${team.total_score || 0}</td>
            </tr>`;

        });

    } catch (err) {
        console.error("loadRanking error:", err);
    }

}

/* =========================
   INIT
========================= */

loadSession();
loadRanking();

// Auto-refresh every 5 seconds
setInterval(() => {
    loadSession();
    loadRanking();
}, 5000);
