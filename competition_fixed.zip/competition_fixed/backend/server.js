const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.use(
    "/api/session",
    require("./routes/session")
);

app.use(
    "/api/submission",
    require("./routes/submission")
);

app.use(
    "/api/auth",
    require("./routes/auth")
);

app.listen(3000,()=>{

    console.log(
        "SERVER RUNNING ON PORT 3000"
    );

});