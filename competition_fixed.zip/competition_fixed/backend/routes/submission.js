const express = require("express");
const router = express.Router();
const db = require("../config/db");

/* =========================
   GET SUBMISSIONS
========================= */

router.get("/", (req, res) => {

    db.query(
        `SELECT *,
        (
            frontend_score +
            backend_score +
            ui_score +
            performance_score
        ) AS total_score
        FROM submissions
        ORDER BY total_score DESC`,
        (err, result) => {

            if (err) {
                console.error(err);
                return res.status(500).json(err);
            }

            res.json(result);

        }
    );

});

/* =========================
   SUBMIT PROJECT
   BUG FIX: validate required fields
========================= */

router.post("/", (req, res) => {

    const { frontend_url, backend_url } = req.body;

    if (!frontend_url || !backend_url) {
        return res.status(400).json({
            success: false,
            message: "frontend_url and backend_url are required"
        });
    }

    db.query(
        `INSERT INTO submissions(frontend_url, backend_url, status)
         VALUES(?, ?, ?)`,
        [frontend_url, backend_url, "SUBMITTED"],
        (err, result) => {

            if (err) {
                console.error(err);
                return res.status(500).json(err);
            }

            res.json({ success: true, id: result.insertId });

        }
    );

});

/* =========================
   UPDATE SCORE
========================= */

router.put("/score/:id", (req, res) => {

    const frontend_score    = Number(req.body.frontend_score);
    const backend_score     = Number(req.body.backend_score);
    const ui_score          = Number(req.body.ui_score);
    const performance_score = Number(req.body.performance_score);
    const id                = Number(req.params.id);

    // Validate score ranges (0-25 each)
    const scores = [frontend_score, backend_score, ui_score, performance_score];
    for (const s of scores) {
        if (isNaN(s) || s < 0 || s > 25) {
            return res.status(400).json({
                success: false,
                message: "Each score must be between 0 and 25"
            });
        }
    }

    db.query(
        `UPDATE submissions
         SET
            frontend_score=?,
            backend_score=?,
            ui_score=?,
            performance_score=?,
            status='SCORED'
         WHERE id=?`,
        [frontend_score, backend_score, ui_score, performance_score, id],
        (err, result) => {

            if (err) {
                console.error(err);
                return res.status(500).json(err);
            }

            res.json({ success: true, result });

        }
    );

});

/* =========================
   BUG FIX: recheck route was missing — judge.js calls this
========================= */

router.post("/:id/recheck", (req, res) => {

    const id = Number(req.params.id);

    db.query(
        "UPDATE submissions SET status='PENDING' WHERE id=?",
        [id],
        (err) => {

            if (err) {
                console.error(err);
                return res.status(500).json({ success: false });
            }

            res.json({ success: true, message: "Submission marked for re-check" });

        }
    );

});

module.exports = router;
