const express = require("express");
const router = express.Router();
const db = require("../config/db");

router.get("/status", (req, res) => {

    db.query(
        "SELECT * FROM session_control LIMIT 1",
        (err, result) => {

            if (err) {
                return res.status(500).json({ success: false });
            }

            if (!result || result.length === 0) {
                return res.status(404).json({ success: false, message: "No session found" });
            }

            res.json(result[0]);

        }
    );

});

// BUG FIX: update start_time and end_time when opening session
router.put("/open", (req, res) => {

    db.query(
        `UPDATE session_control
         SET status='open',
             start_time=NOW(),
             end_time=DATE_ADD(NOW(), INTERVAL 3 HOUR)
         WHERE id=1`,
        (err) => {

            if (err) {
                return res.status(500).json({ success: false });
            }

            res.json({ success: true });

        }
    );

});

router.put("/close", (req, res) => {

    db.query(
        "UPDATE session_control SET status='closed' WHERE id=1",
        (err) => {

            if (err) {
                return res.status(500).json({ success: false });
            }

            res.json({ success: true });

        }
    );

});

module.exports = router;
