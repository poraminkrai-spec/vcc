const express = require("express");
const router = express.Router();
const db = require("../config/db");

router.post("/login", (req, res) => {

    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            success: false,
            message: "Username and password are required"
        });
    }

    db.query(
        "SELECT * FROM users WHERE username=? AND password=?",
        [username, password],
        (err, result) => {

            if (err) {
                console.error(err);
                return res.status(500).json({
                    success: false,
                    message: "Database error"
                });
            }

            if (result && result.length > 0) {

                res.json({
                    success: true,
                    role: result[0].role
                });

            } else {

                res.status(401).json({
                    success: false,
                    message: "Invalid Login"
                });

            }

        }
    );

});

module.exports = router;
