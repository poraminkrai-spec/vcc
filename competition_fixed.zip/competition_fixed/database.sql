CREATE DATABASE IF NOT EXISTS competition_system;

USE competition_system;

/* =========================
   USERS
========================= */

CREATE TABLE IF NOT EXISTS users (

    id INT PRIMARY KEY AUTO_INCREMENT,

    username VARCHAR(50) NOT NULL,

    password VARCHAR(255) NOT NULL,

    role VARCHAR(20) NOT NULL

);

/* =========================
   DEFAULT USERS
========================= */

INSERT INTO users(username,password,role)
VALUES

('candidate','1234','candidate'),
('judge','1234','judge'),
('manager','1234','manager');

/* =========================
   SESSION CONTROL
========================= */

CREATE TABLE IF NOT EXISTS session_control (

    id INT PRIMARY KEY AUTO_INCREMENT,

    status VARCHAR(20) DEFAULT 'closed',

    start_time DATETIME,

    end_time DATETIME

);

/* =========================
   DEFAULT SESSION
========================= */

INSERT INTO session_control(
    status,
    start_time,
    end_time
)

SELECT

    'closed',

    NOW(),

    DATE_ADD(NOW(),INTERVAL 3 HOUR)

WHERE NOT EXISTS (

    SELECT *
    FROM session_control

);

/* =========================
   SUBMISSIONS
========================= */

CREATE TABLE IF NOT EXISTS submissions (

    id INT PRIMARY KEY AUTO_INCREMENT,

    frontend_url TEXT,

    backend_url TEXT,

    status VARCHAR(50) DEFAULT 'PENDING',

    frontend_score INT DEFAULT 0,

    backend_score INT DEFAULT 0,

    ui_score INT DEFAULT 0,

    performance_score INT DEFAULT 0,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

/* =========================
   SAMPLE DATA
========================= */

INSERT INTO submissions(

    frontend_url,
    backend_url,
    status,
    frontend_score,
    backend_score,
    ui_score,
    performance_score

)

VALUES

(
    'https://team1.vercel.app',
    'https://team1-api.onrender.com',
    'SUBMITTED',
    20,
    18,
    22,
    19
),

(
    'https://team2.vercel.app',
    'https://team2-api.onrender.com',
    'SUBMITTED',
    24,
    23,
    22,
    24
),

(
    'https://team3.vercel.app',
    'https://team3-api.onrender.com',
    'SUBMITTED',
    16,
    14,
    18,
    17
);

/* =========================
   VIEW TOTAL SCORE
========================= */

CREATE OR REPLACE VIEW ranking_view AS

SELECT

    id,

    frontend_url,

    backend_url,

    status,

    frontend_score,

    backend_score,

    ui_score,

    performance_score,

    (

        frontend_score +

        backend_score +

        ui_score +

        performance_score

    ) AS total_score

FROM submissions

ORDER BY total_score DESC;

/* =========================
   TEST
========================= */

SELECT * FROM users;

SELECT * FROM submissions;

SELECT * FROM ranking_view;

SELECT * FROM session_control;