'use strict';

const API_BASE = 'http://localhost:3000/api';

// Enter key submits form
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('input').forEach(input => {
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') login();
    });
  });
});

async function login() {
  const usernameEl = document.getElementById('username');
  const passwordEl = document.getElementById('password');
  const statusEl   = document.getElementById('status');
  const btn        = document.getElementById('login-btn');

  const username = usernameEl.value.trim();
  const password = passwordEl.value;

  // Clear previous error
  statusEl.textContent = '';
  statusEl.classList.remove('visible');

  if (!username || !password) {
    showError('Please enter your username and password.');
    return;
  }

  // Loading state
  btn.setAttribute('data-loading', '');
  btn.disabled = true;
  btn.textContent = 'Signing in...';

  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ username, password }),
    });

    const data = await res.json();

    if (data.success) {
      btn.textContent = 'Redirecting...';

      const routes = {
        candidate: 'pages/candidate.html',
        judge:     'pages/judge.html',
        manager:   'pages/manager.html',
      };

      const dest = routes[data.role];
      if (dest) {
        window.location.href = dest;
      } else {
        showError('Unknown role. Contact an administrator.');
        resetBtn();
      }
    } else {
      showError('Invalid username or password.');
      passwordEl.value = '';
      passwordEl.focus();
      resetBtn();
    }

  } catch (err) {
    console.error('Login error:', err);
    showError('Unable to connect to the server. Please try again.');
    resetBtn();
  }

  function showError(msg) {
    statusEl.textContent = msg;
    statusEl.classList.add('visible');
  }

  function resetBtn() {
    btn.removeAttribute('data-loading');
    btn.disabled = false;
    btn.textContent = 'Continue';
  }
}
