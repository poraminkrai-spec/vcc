/* ============================================================
   SHARED UTILITIES — Competition Platform
   ============================================================ */

'use strict';

const API = 'http://localhost:3000/api';

/* ────────────────────────────────────────────────────────────
   TOAST
──────────────────────────────────────────────────────────── */
function showToast(message, type = 'info', duration = 3200) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.setAttribute('role', 'alert');

  const iconMap = {
    success: '<svg class="toast-icon" viewBox="0 0 16 16" fill="none"><path d="M3 8l3 3 7-7" stroke="var(--success)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    error:   '<svg class="toast-icon" viewBox="0 0 16 16" fill="none"><path d="M4 4l8 8M12 4l-8 8" stroke="var(--danger)" stroke-width="1.5" stroke-linecap="round"/></svg>',
    info:    '<svg class="toast-icon" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6" stroke="var(--accent)" stroke-width="1.3"/><path d="M8 7v4M8 5.5v.5" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round"/></svg>',
  };

  toast.innerHTML = `${iconMap[type] || iconMap.info}<span>${message}</span>`;
  container.appendChild(toast);

  const remove = () => {
    toast.classList.add('exiting');
    toast.addEventListener('animationend', () => toast.remove(), { once: true });
  };

  const timer = setTimeout(remove, duration);
  toast.addEventListener('click', () => { clearTimeout(timer); remove(); });
}


/* ────────────────────────────────────────────────────────────
   FETCH HELPERS
──────────────────────────────────────────────────────────── */
async function apiFetch(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.message || `HTTP ${response.status}`);
  }
  return response.json();
}

/* ────────────────────────────────────────────────────────────
   CLOCK
──────────────────────────────────────────────────────────── */
function updateClock(elementId) {
  const el = document.getElementById(elementId);
  if (!el) return;
  const now = new Date();
  const date = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  const time = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  el.textContent = `${date} · ${time}`;
}

/* ────────────────────────────────────────────────────────────
   TIMER
──────────────────────────────────────────────────────────── */
function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

/* ────────────────────────────────────────────────────────────
   RANKING RENDERER
──────────────────────────────────────────────────────────── */
function renderRankingTable(data, tbodyId) {
  const tbody = document.getElementById(tbodyId);
  if (!tbody) return;

  const sorted = [...data].sort((a, b) => (b.total_score || 0) - (a.total_score || 0));

  if (sorted.length === 0) {
    tbody.innerHTML = `<tr><td colspan="3"><div class="empty-state"><div class="empty-state-title">No ranked teams yet</div></div></td></tr>`;
    return;
  }

  tbody.innerHTML = sorted.map((team, i) => {
    const medals = ['🥇','🥈','🥉'];
    const rank = i < 3
      ? `<span class="rank-medal">${medals[i]}</span>`
      : `<span class="rank-cell">#${i + 1}</span>`;

    const score = team.total_score || 0;
    const scoreColor = score >= 70 ? 'var(--success)' : score > 0 ? 'var(--warning)' : 'var(--text-tertiary)';

    return `
      <tr>
        <td>${rank}</td>
        <td style="color:var(--text-primary);font-weight:500">Team ${team.id}</td>
        <td><span style="font-family:var(--font-mono);font-size:13px;color:${scoreColor};font-weight:600">${score}</span></td>
      </tr>
    `;
  }).join('');
}
