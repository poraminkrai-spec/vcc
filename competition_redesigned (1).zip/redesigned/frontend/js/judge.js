'use strict';

/* ────────────────────────────────────────────────────────────
   STATE
──────────────────────────────────────────────────────────── */
const DEFAULT_DURATION = 3 * 60 * 60;
let duration     = DEFAULT_DURATION;
let timerStarted = false;
let sessionState = 'closed';

/* ────────────────────────────────────────────────────────────
   CLOCK
──────────────────────────────────────────────────────────── */
setInterval(() => updateClock('clock'), 1000);
updateClock('clock');

/* ────────────────────────────────────────────────────────────
   TIMER
──────────────────────────────────────────────────────────── */
function renderTimer() {
  const el = document.getElementById('timer');
  if (!el) return;
  el.textContent = formatDuration(Math.max(0, duration));
  el.className = 'timer-display' + (timerStarted && duration > 0 ? ' running' : duration <= 0 ? ' expired' : '');
}

renderTimer();

setInterval(() => {
  if (timerStarted && duration > 0) {
    duration--;
    renderTimer();
  }
}, 1000);

/* ────────────────────────────────────────────────────────────
   SESSION STATUS
──────────────────────────────────────────────────────────── */
async function loadStatus() {
  try {
    const data  = await apiFetch('/session/status');
    const isOpen = data.status === 'open';

    const dot   = document.getElementById('session-dot');
    const label = document.getElementById('sessionStatus');

    if (dot)   dot.className    = `session-dot${isOpen ? ' live' : ''}`;
    if (label) label.textContent = isOpen ? 'Live' : 'Closed';

    if (isOpen) {
      if (sessionState !== 'open' && data.end_time) {
        duration = Math.max(0, Math.floor((new Date(data.end_time) - new Date()) / 1000));
        renderTimer();
      }
      timerStarted = true;
      sessionState = 'open';
    } else {
      timerStarted = false;
      sessionState = 'closed';
      if (duration !== DEFAULT_DURATION) {
        duration = DEFAULT_DURATION;
        renderTimer();
      }
    }
  } catch (err) {
    console.error('loadStatus error:', err);
  }
}

/* ────────────────────────────────────────────────────────────
   OPEN / CLOSE SESSION
──────────────────────────────────────────────────────────── */
async function openSession() {
  const btn = document.getElementById('btn-open');
  btn.setAttribute('data-loading', '');
  btn.disabled = true;

  try {
    const data = await apiFetch('/session/open', { method: 'PUT' });
    if (data.success) {
      showToast('Session opened. Competition is now live.', 'success');
      loadStatus();
    } else {
      showToast('Failed to open session.', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Server error. Could not open session.', 'error');
  } finally {
    btn.removeAttribute('data-loading');
    btn.disabled = false;
  }
}

async function closeSession() {
  const btn = document.getElementById('btn-close');
  btn.setAttribute('data-loading', '');
  btn.disabled = true;

  try {
    const data = await apiFetch('/session/close', { method: 'PUT' });
    if (data.success) {
      showToast('Session closed.', 'info');
      loadStatus();
    } else {
      showToast('Failed to close session.', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Server error. Could not close session.', 'error');
  } finally {
    btn.removeAttribute('data-loading');
    btn.disabled = false;
  }
}

/* ────────────────────────────────────────────────────────────
   SUBMISSIONS
──────────────────────────────────────────────────────────── */
async function loadSubmissions() {
  try {
    const data  = await apiFetch('/submission');
    const tbody = document.getElementById('submissionTable');
    if (!tbody) return;

    if (data.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4"><div class="empty-state"><div class="empty-state-title">No submissions yet</div><div class="empty-state-desc">Submissions will appear here once teams submit.</div></div></td></tr>`;
      return;
    }

    tbody.innerHTML = data.map(item => {
      const statusMap = {
        SUBMITTED: { cls: 'badge-warning', label: 'Submitted' },
        SCORED:    { cls: 'badge-success', label: 'Scored'    },
      };
      const s = statusMap[item.status] || { cls: 'badge-neutral', label: item.status || 'Pending' };

      return `
        <tr>
          <td><span class="rank-cell">#${item.id}</span></td>
          <td><span class="mono">${item.frontend_url || '—'}</span></td>
          <td><span class="badge ${s.cls}">${s.label}</span></td>
          <td>
            <button class="btn-ghost btn-sm" onclick="recheck(${item.id})">Re-check</button>
          </td>
        </tr>`;
    }).join('');
  } catch (err) {
    console.error('loadSubmissions error:', err);
  }
}

/* ────────────────────────────────────────────────────────────
   RECHECK
──────────────────────────────────────────────────────────── */
async function recheck(id) {
  try {
    const data = await apiFetch(`/submission/${id}/recheck`, { method: 'POST' });
    if (data.success) {
      showToast(`Re-check triggered for #${id}.`, 'info');
      loadSubmissions();
    }
  } catch (err) {
    console.error(err);
    showToast('Re-check failed.', 'error');
  }
}

/* ────────────────────────────────────────────────────────────
   SECTION SWITCH OVERRIDE
──────────────────────────────────────────────────────────── */
const _origShowSection = showSection;
function showSection(sectionId, navEl) {
  _origShowSection(sectionId, navEl);
  if (sectionId === 'rankingSection') {
    apiFetch('/submission').then(data => renderRankingTable(data, 'rankingTable')).catch(console.error);
  }
}

/* ────────────────────────────────────────────────────────────
   INIT
──────────────────────────────────────────────────────────── */
loadStatus();
loadSubmissions();

setInterval(() => {
  loadStatus();
  loadSubmissions();
}, 3000);

/* showSection override — load ranking when switching to that tab */
function showSection(sectionId, navEl) {
  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  const target = document.getElementById(sectionId);
  if (target) target.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(el => { el.classList.remove('active'); el.removeAttribute('aria-current'); });
  if (navEl) { navEl.classList.add('active'); navEl.setAttribute('aria-current', 'page'); }
  const titleEl = document.getElementById('page-title');
  if (titleEl && navEl) titleEl.textContent = navEl.textContent.trim();
  if (sectionId === 'rankingSection') {
    apiFetch('/submission').then(data => renderRankingTable(data, 'rankingTable')).catch(console.error);
  }
  if (sectionId === 'submissionSection') loadSubmissions();
}
