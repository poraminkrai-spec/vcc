'use strict';

/* ────────────────────────────────────────────────────────────
   SECTION SWITCH — override from utils
──────────────────────────────────────────────────────────── */
// utils.js showSection is available globally

/* ────────────────────────────────────────────────────────────
   DATA LOAD
──────────────────────────────────────────────────────────── */
async function loadData() {
  try {
    const data = await apiFetch('/submission');
    renderDashboard(data);
    renderScores(data);
    renderRankingTable(data, 'rankingTable');
  } catch (err) {
    console.error('loadData error:', err);
  }
}

/* ────────────────────────────────────────────────────────────
   DASHBOARD STATS
──────────────────────────────────────────────────────────── */
function renderDashboard(data) {
  const total = data.length;
  const pass  = data.filter(t => (t.total_score || 0) >= 70).length;
  const fail  = total - pass;

  animateCount('totalCandidates', total);
  animateCount('passCount', pass);
  animateCount('failCount', fail);
}

function animateCount(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  const start    = parseInt(el.textContent) || 0;
  const duration = 400;
  const startTs  = performance.now();

  function step(ts) {
    const progress = Math.min((ts - startTs) / duration, 1);
    const eased    = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    el.textContent = Math.round(start + (target - start) * eased);
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ────────────────────────────────────────────────────────────
   SCORE PANEL
──────────────────────────────────────────────────────────── */
function renderScores(data) {
  const container = document.getElementById('scoreTable');
  if (!container) return;

  if (data.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <div class="empty-state-title">No submissions yet</div>
        <div class="empty-state-desc">Submissions will appear here once teams submit their projects.</div>
      </div>`;
    return;
  }

  const criteria = [
    { key: 'frontend',    label: 'Frontend',    max: 25 },
    { key: 'backend',     label: 'Backend',     max: 25 },
    { key: 'ui',          label: 'UI / UX',     max: 25 },
    { key: 'performance', label: 'Performance', max: 25 },
  ];

  container.innerHTML = data.map(team => {
    const total = team.total_score || 0;

    const sliders = criteria.map(({ key, label, max }) => {
      const val = team[`${key}_score`] || 0;
      return `
        <div class="range-group">
          <div class="range-header">
            <span class="range-label">${label}</span>
            <span class="range-value" id="${key}-value-${team.id}">${val}</span>
          </div>
          <input
            type="range"
            min="0" max="${max}" value="${val}"
            id="${key}-${team.id}"
            aria-label="${label} score for Team ${team.id}"
            oninput="document.getElementById('${key}-value-${team.id}').textContent=this.value"
          >
        </div>`;
    }).join('');

    return `
      <div class="score-card">
        <div class="score-card-header">
          <div>
            <div class="score-card-title">Team #${team.id}</div>
            <div class="score-card-url">${team.frontend_url || 'No URL submitted'}</div>
          </div>
          <div class="score-total-badge">${total} pts</div>
        </div>
        <div class="score-card-body">
          ${sliders}
        </div>
        <div class="score-card-footer">
          <button class="btn-primary btn-sm" onclick="saveScore(${team.id})">
            Save Score
          </button>
        </div>
      </div>`;
  }).join('');
}

/* ────────────────────────────────────────────────────────────
   SAVE SCORE
──────────────────────────────────────────────────────────── */
async function saveScore(id) {
  const fields = ['frontend', 'backend', 'ui', 'performance'];
  const payload = {};

  for (const f of fields) {
    const el = document.getElementById(`${f}-${id}`);
    if (!el) { showToast('Score inputs not found.', 'error'); return; }
    payload[`${f}_score`] = Number(el.value);
  }

  try {
    const data = await apiFetch(`/submission/score/${id}`, {
      method: 'PUT',
      body:   JSON.stringify(payload),
    });

    if (data.success) {
      showToast(`Team #${id} score saved.`, 'success');
      loadData();
    } else {
      showToast(data.message || 'Failed to save score.', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Server error. Could not save score.', 'error');
  }
}

/* ────────────────────────────────────────────────────────────
   INIT
──────────────────────────────────────────────────────────── */
loadData();
setInterval(loadData, 5000);

/* showSection override */
function showSection(sectionId, navEl) {
  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  const target = document.getElementById(sectionId);
  if (target) target.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(el => { el.classList.remove('active'); el.removeAttribute('aria-current'); });
  if (navEl) { navEl.classList.add('active'); navEl.setAttribute('aria-current', 'page'); }
  const titleEl = document.getElementById('page-title');
  if (titleEl && navEl) titleEl.textContent = navEl.textContent.trim();
}
